﻿using UnityEngine;
using System.Collections.Generic;
using System;
using Global;

namespace RandomBoxMuller
{
    using System;

    public class random
    {
        Random rand;

        public random()
        {
            rand = new Random(Environment.TickCount);
        }
        public random(int seed)
        {
            rand = new Random(seed);
        }
        
        public int Value(int meen,int div)
       {
            var A = rand.NextDouble();
            var B = rand.NextDouble();
            var result = 0.0;
            if(rand.Next() < 1)
             result = Math.Sqrt(-2.0 * Math.Log(A)) * Math.Cos(2.0 * Math.PI * B);
            else
                result = Math.Sqrt(-2.0 * Math.Log(A)) * Math.Sin(2.0 * Math.PI * B);

            return (int)Math.Round(result,MidpointRounding.AwayFromZero);

       }
        public int Next(int min,int max)
        {
            return rand.Next(min, max);
        }
    }
}



[RequireComponent(typeof(Rigidbody))]
public class Enemy : MonoBehaviour
{
    
    float count = Defalt_Count;//回転時間
    const float n = 0.1f;//回転時間の減少量 
    [SerializeField]
    Quaternion rotation;//回転量

    bool HitFlag;//自分に直接ヒットしたかどうか
    

    SENSOR eye;         //視覚センサー
    Collider hitInfo;   //当たった情報
    [SerializeField]
    string TargetTag;   //探索するタグ
    Collider target;    //当たったオブジェクトが入る。なければnull
    Collider DAMMY;     //ダミー用

    void Start()
    {
   
        eye = GetComponent<Eye>();          //センサーを登録
        DAMMY = GetComponent<Collider>();   //ダミー用のコライダーを登録

    }

    /// <summary>
    /// 時間内からこれで許して
    /// </summary>
    void Update()
    {
        if (eye.IsHit())
        {
            target = eye.IsCollider();
            chase();
        }
        else
        {
            search();

        }
        if (HitFlag)
        {
            Destroy(target.gameObject);
            HitFlag = false;
            transform.rotation = Quaternion.identity;
            target = DAMMY;
        }
    }
    
    /// <summary>
    /// 自分自身に当たっているかいないか
    /// 当たっていればHitFlagがtrueになる。
    /// </summary>
    /// <param name="col"></param>
    void OnCollisionEnter(Collision col)
    {
       
        if (col.collider.tag == TargetTag)
        {
            HitFlag = true;
        }
    }



    /// <summary>
    /// 左右きょろきょろさせる。
    /// </summary>
    protected void search()
    {
        transform.rotation *= rotation;
        count -= n;
        if (count <= 0)
        {
            count = Defalt_Count * 2;
            rotation.Set(rotation.x * -1, rotation.y * -1, rotation.z * -1, rotation.w);
        }
        
    }

    /// <summary>
    /// 追いかける。
    /// </summary>
    protected void chase()
    {
        transform.LookAt(target.transform);
        transform.position = Vector3.Lerp(transform.position, target.transform.position, Defalt_Time * Move_Speed);
    }



    static readonly float Defalt_Count = 7.0f;//キョロキョロの際に使用
    static readonly float Defalt_Time = 0.1f;//Lerpで使用
    static readonly float Move_Speed = 0.1f;//Lerpで使用
}


﻿using UnityEngine;
using Global;

interface SENSOR
{
    bool IsHit();           //当たっているかの情報を取得する。
    Collider IsCollider();  //コライダー情報を取得する。
}

 class Eye:MonoBehaviour, SENSOR
{
    [SerializeField]
    private float Scale;        //BoxRayの(四角)大きさ
    [SerializeField]
    private float Range;        //BoxRayの長さ

    //private RayInfo<BoxRay> rayInfo;//BoxRayの情報を格納
    private Global.RayInfo<Ray> rayInfo;

    private bool isHit;               //ヒットしたかどうか

    //ヒットしていればtrue
    public bool IsHit()
    {
        return isHit;
    }

    //無ければnull
    public Collider IsCollider()
    {
        return rayInfo.hit.collider;
    }


    void Start()
    {
        rayInfo = new RayInfo<Ray>();
        isHit = false;
        //RAY更新情報
        rayInfo.ray.direction = transform.forward;
    }



    //void OnDrawGizmos()
    void FixedUpdate()
    {
        //RAY更新情報
        rayInfo.ray.origin = transform.position;
        rayInfo.ray.direction = transform.forward;

        //ヒットしたらtrue
        //isHit =
        //    Physics.SphereCast(
        //        rayInfo.ray.center,               
        //        rayInfo.ray.scale,
        //        rayInfo.ray.direction,
        //        out rayInfo.hit,
        //        Range);

        isHit =
            Physics.Raycast(
                rayInfo.ray, out rayInfo.hit, Range);

    }


    //static readonly float SCARING = 3f;


 }


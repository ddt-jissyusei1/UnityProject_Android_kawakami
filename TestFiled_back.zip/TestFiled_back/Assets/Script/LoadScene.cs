﻿using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// シーンを読み込む
/// </summary>
public class LoadScene : MonoBehaviour
{

    [SerializeField]
    private string sceneName;//呼び出したいシーンの名前。
    [SerializeField]
    private GameObject DestroyMan;//デストロイマン用。

    bool isTitle;                 //タイトル用フラグ。
    [SerializeField]
    float timeCount;              //遅延用inspector上で操作
    float current;                //時間計測用。

    /// <summary>
    /// タイトルフラグを初期化
    /// </summary>
    void Start()
    {
        isTitle = false;
        current = 0.0f;
    }

    /// <summary>
    /// Unityのロゴが消えたら
    /// 真になる。
    /// </summary>
    void Update()
    {
        
        if (!Application.isShowingSplashScreen)
        {
            isTitle = true;
            current += Time.deltaTime;
            current = Mathf.Clamp(current, 0.0f, timeCount + 1);//わざと+1しています。
        }
    }


    //イベント関数用
    public void On()
    {
        //ロゴなしかつ時間が超えていれば
        if (isTitle && current >= timeCount)
        {
            SceneManager.LoadScene(sceneName);
        }
        if (DestroyMan != null) Instantiate(DestroyMan);
    }

}

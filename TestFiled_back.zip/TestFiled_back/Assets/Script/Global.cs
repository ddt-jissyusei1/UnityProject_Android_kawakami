﻿
using UnityEngine;

//宣言エリア
namespace Global
{
    /// <summary>
    /// 登場シーンと帰るシーンのアニメーションの時間（母艦）
    /// </summary>
    public static class MatherShipAnimationTimes
    {
        static public readonly float StartAcitonTime       = 5.0f;//スタートシーンの総合時間.
        static public readonly float StartMoveTime         = 3.0f;//進む処理時間
        static public readonly float StartMoveWaitTime     = 0.0f;//進む処理前の待ち時間
        static public readonly float StartDownTime         = 3.0f;//母艦が下がる処理時間
        static public readonly float StartDownWaitTime     = 3.0f;//下がる処理の待ち時間
        static public readonly float StartRotationTime     = 2.0f;//回転する処理時間
        static public readonly float StartRotationWaitTime = 3.0f;//処理前の待ち時間。

        //プレイヤーを拾う処理
        static public readonly float AdvancedActionTime = 999f;//拾う処理の全体時間
        static public readonly float AdvancedDowTime    = 999; //下がる時間

        static public readonly float EndActionTime       = 15.0f;//エンドシーンの総合時間
        static public readonly float EndMoveTime         = 10.0f;//進む処理時間
        static public readonly float EndMoveWaitTime     = 8.0f; //進む処理前の待ち時間
        static public readonly float EndUpTime           = 8.0f; //母艦が上がる処理時間
        static public readonly float EndUpWaitTime       = 0.0f; //上がる処理の待ち時間
        static public readonly float EndRotationTime     = 8.0f; //回転する処理時間
        static public readonly float EndRotationWaitTime = 0.0f; //処理前の待ち時間
       
       
    }

    /// <summary>
    /// 
    /// Overview:
    ///     Ltagの宣言・文字列間違い防止用。
    ///     Lホントのとこシーンごとにオブジェクト分けて宣言を・・・
    /// </summary>
    public static class sTags
    {
        static public readonly string Player            = "Player";         //プレイヤーのタグ
        static public readonly string Clear             = "ClearArea";      //ゲームのクリアのエリア
        static public readonly string Start             = "StartArea";      //実質使っていない
        static public readonly string on                = "CatchArmOn";     //アームのOnの状態（伸ばしている状態）
        static public readonly string off               = "CatchArmOff";    //アームのOffの状態（戻る状態）
        static public readonly string dammy             = "dammy";          //ダミー用（アームが何もしていない状態）
        static public readonly string COLLISIONCLEAR    = "Clear";          //ブロックのジョイント解除用
        static public readonly string Are               = "Are";            //鉱石のRayがブロックに当たっている状態
        static public readonly string AreHidden         = "HiddenAre";      //鉱石が太陽にRayが当たっている状態
        static public readonly string Block             = "Block";          //影を作るオブジェクト
        static public readonly string Filed             = "FILED";          //地面Rayとの認識はない。
        //static public readonly string Panel_Two         = "SolarPanel_Two"; 
        //static public readonly string Panel_One         = "SolarPanel_One"; 
        static public readonly string CrearPosition     = "ClearPosition";  //クリアオブジェクトがある位置。
        static public readonly string WALL              = "HiddenWall";     //ステージ上にある見えない壁
    }

    /// <summary>
    /// 各シーンの名前の宣言。
    /// </summary>
    public static class SceneName
    {
        static public readonly string Menu          = "MENU";
        static public readonly string Result        = "Result";
        static public readonly string Title         = "Title";
        static public readonly string gameOver      = "GameOver";
      
        static public readonly string Level1        = "Level1";
        static public readonly string Level2        = "Level2";
        static public readonly string Level3        = "Level3";
        static public readonly string Level4        = "Level4";
    }

    /// <summary>
    /// Overview:
    ///     Lプレイヤーの状態の指標
    /// </summary>
    public enum PLAYERSTATE:int
    {
        eCLEAR  = 0,
        //ゲームモード
        ePLAY   = 1,
        eWAIT   = 2,
        //アニメーションモード
        eStart  = 3,
        eEnd    = 4
    }

    
    /// <summary>
    /// Overview:
    ///     LBox型のRayの情報保持用。
    /// 
    /// Param:
    ///     Lscale:ボックスのサイズ（半分）
    ///     Lcenter:ボックスの中心座標
    ///     Ldirection:方向
    ///     Lroutation:回転
    /// </summary>
    public struct BoxRay
    {
        public float scale;         
        public Vector3 center;     
        public Vector3 direction;  
        public Quaternion rotation;

        public BoxRay(float _scale, Vector3 _center, Vector3 _direction, Quaternion _rotation)
        {
            scale = _scale;
            center = _center;
            direction = _direction;
            rotation = _rotation;
        }

    }


    /// <summary>
    /// Overview:
    ///     LRaycastの情報、Ray情報とRaycastHIｔ情報を保持
    ///     
    /// Param:
    ///     Lray: RayTypeで指定した型のRay情報を保持
    ///     Lhit: Raycastで当たった情報が格納される。
    /// </summary>
    /// <typeparam name="RayType"></typeparam>
    public class RayInfo<RayType>
    {
        public RayType    ray;
        public RaycastHit hit;
    }

    /// <summary>
    /// Author:川上　遵
    /// 
    /// Overview:
    ///     L型が同じオブジェクトを渡す際に使用。
    /// 
    /// Param:
    ///     Lfirst: 管理する変数
    ///     Lsecond:管理する変数
    /// 
    /// </summary>
    /// <typeparam name="type">2つの共通の型を指定</typeparam>
    public struct Pair<type>
    {
        public type first;
        public type second;
    }

    /// <summary>
    /// Author:川上　遵
    /// 
    /// Overview:
    ///     上記の拡張版.
    /// </summary>
    /// <typeparam name="typex">属性１</typeparam>
    /// <typeparam name="typey">属性２</typeparam>
    public struct Pair<typex,typey>
    {
        public typex first;
        public typey second;
    }


    /// <summary>
    /// Author:川上　遵
    /// 
    /// Overview:
    ///     L時間計測用に保持する構造体
    /// 
    /// Param:
    ///     Lh:時間
    ///     Lm:分
    ///     Ls:秒
    /// 
    /// </summary>
    public struct TIME
    {
        public int h, m, s;


        /// <summary>
        /// 秒を返す。
        /// </summary>
        public float seccond
        {
            get { return (h * 60 * 60 + m * 60 + s); }
        }

        /// <summary>
        /// 分を返す。
        /// </summary>
        public float minute
        {
            get
            {
                return h * 60 + m;
            }
        }
    }

    /// <summary>
    /// Overview:
    ///    L制限時間と現在時間を保持用（いちいち作るのがめんどくさかったから。）
    /// 
    /// Param:
    ///     LTimeLimit: 制限時間
    ///     LCurrentTime:現在時間
    ///     
    /// Method:
    ///     LTimeInfo:コンストラクタ
    /// </summary>
    public struct TimeInfo
    {
        public float TimeLimit;
        public float CurrentTime;
        /// <summary>
        /// 初期化処理
        /// </summary>
        /// <param name="limit">制限時間の初期値</param>
        /// <param name="current">現在時間の初期値</param>
        public TimeInfo(float limit,float current = 0.0f)
        {
            TimeLimit = limit;
            CurrentTime = current;
        }
        
        /// <summary>
        /// CurrentTime > TimeLimitの結果
        /// </summary>
        /// <returns></returns>
        public bool IsOver()
        {
            return TimeLimit < CurrentTime;
        }
    }

    /// <summary>
    /// ストップウォッチ
    /// こちらの方が正確らしい
    /// </summary>
    public struct StopWatch
    {
        private float Start;
        private float End;

        public void onStart()
        {
            Start = Time.timeSinceLevelLoad;
        }
        public void onStop()
        {
            End = Time.timeSinceLevelLoad;
        }
        public float onResult()
        {
            return End - Start;
        }
    }

    /// <summary>
    /// Author:川上　遵
    /// 
    /// Overview:
    ///     LStateパターンのオブジェトでBool型です。
    ///     
    /// Param:
    ///     Lflag:管理する変数。
    ///     
    /// Method:
    ///     LNext():次のBOOLStateに切り替える。
    /// 
    /// </summary>
    abstract public class BOOLState
    {
        public bool flag;

        abstract public BOOLState Next();
    }
    public class TRUE : BOOLState
    {
        public TRUE()
        {
            base.flag = true;
        }
        public override BOOLState Next()
        {
            return new FALSE();
        }
    }
    public class FALSE : BOOLState
    {
        public FALSE()
        {
            base.flag = false;
        }
        public override BOOLState Next()
        {
            return new TRUE();
        }
    }


    //数値状態移行情報クラス
    //Nextを呼び出し、１，０を切り替え
    //データはvalue
    abstract public class State
    {
        public int value;
        abstract public State Next();
    }
    class one : State
    {
        public one()
        {
            base.value = 1;
        }
        public override State Next()
        {
            return new zero();
        }
    }
    class zero : State
    {
        public zero()
        {
            base.value = 0;
        }
        public override State Next()
        {
            return new one();
        }
    }



    /// <summary>
    /// 
    /// Author:川上　遵
    /// 
    /// Overview:
    /// 制限時間を超えた瞬間にFalgが反転する。
    /// Initilizeを呼びださない限り戻らない。
    /// 
    /// Param:
    ///     LFlag:管理するフラグ。
    ///     LtimeInfo:制限時間で変更するために必要。
    ///     
    /// Method:
    ///     LFLAG:Flag変数のセッター
    ///     LAutoBool:コンストラクタ
    ///     LInitilize:初期化
    ///     LonUpdate:タイマーの更新兼Flag反転処理
    ///     LStop:falgを反転させて止めます。再度使用する場合、Initilize()を呼び出してください。
    /// </summary>
    public struct AutoBool
    {
        bool Flag;
        public bool FLAG
        {
            get
            {
                    return Flag;
            }
        }
        TimeInfo timeInfo;

        public AutoBool(float Limit)
        {
            timeInfo.CurrentTime = 0.0f;
            timeInfo.TimeLimit = Limit;

            Flag = true;
        }
        public void Initilize(float Limit)
        {
            timeInfo.TimeLimit = Limit;
            timeInfo.CurrentTime = 0.0f;
            Flag = true;
        }
        public void Initilize()
        {
            timeInfo.CurrentTime = 0.0f;
            Flag = true;
        }
        public void onUpdate()
        {
            timeInfo.CurrentTime += Time.deltaTime;
            if (timeInfo.CurrentTime >= timeInfo.TimeLimit)
                Flag = false;
        }
        public void Stop()
        {
            Flag = false;
        }
    }

    /// <summary>
    /// 参考URL：http://naichilab.blogspot.jp/2013/11/unitymanager.html
    /// singletonの原型。
    /// シングルトンにしたいオブジェクトがあれば
    /// これを継承するだけ
    /// シーン読み込時に消えないのは継承先で記述
    /// </summary>
    /// <typeparam name="GameObjectType"></typeparam>
    public class SingletonMono<GameObjectType>:MonoBehaviour where GameObjectType:MonoBehaviour
    {
        private GameObjectType instance;
        public GameObjectType Instance
        {
            get
            {
                if (instance == null)
                    instance = (GameObjectType)FindObjectOfType(typeof(GameObjectType));              
                return instance;
            }
        }
    }

    /// <summary>
    /// Overview:
    ///     L登録したいオブジェクトの窓口。
    ///     sが抜けているが気にしない。
    /// </summary>
    public interface iPartMonitor
    {
        /// <summary>
        /// 監視対象（アーム）を登録する。
        /// </summary>
        /// <param name="observa">登録する変数</param>
        void RegistrationArm(iParts arm);

        /// <summary>
        /// 登録されている監視対象(アーム)を抹消する。
        /// </summary>
        /// <param name="observa">抹消するオブジェクト名</param>
        void ErasureArm();

        /// <summary>
        /// リストに監視対象（エネルギー共有物）を登録
        /// </summary>
        /// <param name="key"> 何番目</param>
        /// <param name="other">監視対象</param>
        void RegistrationEnergy(iParts other);

    }


    /// <summary>
    /// Overview:
    ///     Lパーツが機能しているかどうか
    /// </summary>
    public interface iParts
    {
        /// <summary>
        /// Overview:
        ///     Lパーツの状態
        /// </summary>
        /// <returns>各オブジェクトの状態</returns>
        int State();
    }

    /// <summary>
    /// Author:川上　遵
    /// 
    /// Overview:
    ///     太陽とゲームコントロールオブジェクトの関係用インターフェース
    ///    
    /// </summary>
    public interface iGameTimeUpdate
    {
        /// <summary>
        /// Overview:
        ///     1秒進める。
        /// </summary>
        void TimeUpdate();
    }


    /// <summary>
    /// void 関数ポインタ配列
    /// お試し
    /// </summary>
    public struct VoidMethodPointer
    {
        VOIDMETHOD[] methods;
        int Size;

        public VoidMethodPointer(int size)
        {
            Size = size;
            methods = new VOIDMETHOD[size];
            //無名関数初期化
            for(int i = 0; i < Size; i++)
            {
                methods[i] = delegate () { };
            }
        }
        public void MethodSET(int i,VOIDMETHOD method)
        {
            methods[i] = method;
        }
        public void Run(int i)
        {
            Mathf.Clamp(i,0,Size);
            methods[i]();
        }
    }
    public delegate void VOIDMETHOD();
}

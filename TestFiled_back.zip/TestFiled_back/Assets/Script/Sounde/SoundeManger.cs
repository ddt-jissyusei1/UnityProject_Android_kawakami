﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System;

public  class SoundeManger : Global.SingletonMono<SoundeManger>
{

    [SerializeField]
    private List<AudioClip> BGMs;
    [SerializeField]
    private List<AudioClip> SEs;

    private AudioSource       BGMsources;//BGMは一曲のみ
    private List<AudioSource> SEsources; //SEは複数再生されるため

    /// <summary>
    /// シーンを読み込んでも
    /// 自動で消えないように設定
    /// </summary>
    void Awake()
    {
        if (Instance != this)
        {
            Destroy(this);
            return;
        }
        DontDestroyOnLoad(this.gameObject);
    }

    /// <summary>
    /// 各リストの初期化
    /// </summary>
    void Start ()
    {
        SEsources = new List<AudioSource>();
        
        BGMsources = CreateAudioSources(BGMs[0], false, true);
        
        //LINQで書きたかった・・・
        foreach (var se in SEs)
        {
            SEsources.Add(CreateAudioSources(se, false, false));
        }
    }
	

    /// <summary>
    /// BGM制御
    /// </summary>
    /// <param name="num"></param>
    public void onPlayBGM(int num)
    {
        BGMsources.clip = BGMs[num];
        BGMsources.PlayOneShot(BGMsources.clip);
    }
    public void onStopBGM()
    {
        BGMsources.Stop();
    }

    /// <summary>
    /// SEの制御
    /// </summary>
    /// <param name="num"></param>
    public void onPlaySE(int num)
    {
        SEsources[num].PlayOneShot(SEs[num]);
    }
    public void onStopSE(int num)
    {
        SEsources[num].Stop();
    }
    public void onStopALL()
    {
        foreach (var se in SEsources) se.Stop();
       
    }


    /// <summary>
    /// AudioSorceを自分のコンポーネントに作成する。
    /// </summary>
    /// <returns></returns>
    private AudioSource CreateAudioSources(AudioClip sounde,bool awakeFlag,bool LoopFlag)
    {
        //自分のコンポーネントに作成。
        var audioSorce         = gameObject.AddComponent<AudioSource>();
        audioSorce.clip        = sounde;     //どのサウンドを設定するのかの設定。
        audioSorce.playOnAwake = awakeFlag;  //最初から再生するのかの設定
        audioSorce.loop        = LoopFlag;   //サウンドのループの設定
        return audioSorce;
    }

   
}

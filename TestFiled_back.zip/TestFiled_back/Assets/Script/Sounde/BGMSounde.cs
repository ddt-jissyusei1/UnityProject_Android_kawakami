﻿using UnityEngine;
using System.Collections;

/// <summary>
/// BGM再生用オブジェクト
///  シーンが終わる（自分が死ぬタイミングで）
///  BGMを止める。
/// </summary>
public class BGMSounde : MonoBehaviour
{

    SoundeManger smanager;//BGM操作用。
    [SerializeField]
    int soudeNum;//何番目のBGMを再生する

    /// <summary>
    /// 初期化関数。
    /// </summary>
	void Start ()
    {
        //サウンドマネージャーの参照。
        smanager = FindObjectOfType<SoundeManger>();
        //BGMを再生。
        smanager.onPlayBGM(soudeNum);
	}
	
    /// <summary>
    /// 死ぬ間際に呼ばれる関数
    /// </summary>
    void OnDisable()
    {
        //BGMを止める。
        smanager.onStopBGM();
    }
}

﻿using UnityEngine;
using System.Collections;

public class Option : MonoBehaviour
{

    [SerializeField][Range(0,1)]
    int SyncCount;
    [SerializeField][Range(15,120)]
    int FPS;

	void Start ()
    {
        //垂直同期OFF
        QualitySettings.vSyncCount = SyncCount;
        //フレームレートを固定
        Application.targetFrameRate = FPS;
        
    }
}

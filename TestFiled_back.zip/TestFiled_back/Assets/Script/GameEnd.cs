﻿using UnityEngine;
using System.Collections;
using Global;

/// <summary>
/// ESCキーでアプリケーションを強制終了する。
/// </summary>
public class GameEnd : SingletonMono<GameEnd>
{
    //シーンが消えても生きるようにする。
    void Awake()
    {
        if (Instance != this)
        {

            Destroy(this);
            return;
        }
        else
             DontDestroyOnLoad(gameObject);
    }


	
	/// <summary>
    /// ESCキーでアプリケーションを強制終了する。
    /// </summary>
	void Update ()
    {

        System.GC.Collect();//ガベコレのタイミングを毎回やらせる。
        if (Input.GetKey(KeyCode.Escape))
            Application.Quit();
    }
}

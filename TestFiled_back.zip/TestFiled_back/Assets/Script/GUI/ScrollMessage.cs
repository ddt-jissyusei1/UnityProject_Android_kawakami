﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using System;

namespace Menu
{
    public class ScrollMessage : MonoBehaviour,iPopUpWindow
    {

        [SerializeField]
        //EventTrigger Canceltrigger;               //キャンセルボタン
        Button cancel;
        private iSimpleWindow createManger;//クリエイトフラグの管理

        public void SetManager(iSimpleWindow manager)
        {
            createManger = manager;
        }


        void Start()
        {
            //イベント登録。
            cancel.onClick.AddListener(() => Cancel());
        }


        /// <summary>
        /// キャンセル押された時用。
        /// </summary>
        void Cancel()
        {
            createManger.CreateFrag = false;
            Destroy(gameObject);
        }
    }
}
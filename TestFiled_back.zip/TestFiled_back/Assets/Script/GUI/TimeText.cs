﻿using UnityEngine;
using UnityEngine.UI;
using Global;

/// <summary>
/// Author:川上遵
/// 　　ライフゲージ
/// 　　名前変えたい！
/// 　　
///     GameControllerから時間を取得し、設定を行う。
/// 
/// </summary>
[RequireComponent(typeof(Slider))]
public class TimeText : MonoBehaviour
{

    Slider slider;
    iUIobserver gameController;
    float currentPoint;

    /// <summary>
    /// Overview:
    ///     Lui,GMの取得.
    /// </summary>
	void Start ()
    {
        slider = GetComponent<Slider>();
        gameController = FindObjectOfType<GameController>();

        var count = gameController.GetTimers();

        //最大値を設定。
        slider.maxValue = count.second;
        slider.value = slider.maxValue;

        currentPoint = 0.0f;
	}
	
	/// <summary>
    /// Overview:
    ///     LGameControllerオブジェクトから時間を参照し表示する。
    /// </summary>
	void Update ()
    {
        var point = gameController.GetTimers().first.seccond;

       
        slider.value += currentPoint - point;

        //現在ポイントを更新。
        currentPoint = point;
        
	}

}

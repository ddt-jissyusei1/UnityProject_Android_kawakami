﻿using UnityEngine;
using UnityEngine.UI;


/// <summary>
/// Author:川上　遵
/// 
/// Overview:
///     LGameControllerの時間情報を表示する。
/// 
/// Param:※修正し局所変数にしました。
///     LGM:GameControllerからの情報参照用。
///     LUI:表示されるテキストの操作を行う。
/// </summary>
[RequireComponent(typeof(Text))]
public class ResultText : MonoBehaviour
{

    /// <summary>
    /// 局所変数に入れない方がよかったかも
    /// </summary>
	void Start ()
    {
        var GM = FindObjectOfType<GameController>();
        var UI = GetComponent<Text>();

       
        var Point = GM.GetScore();
           
        UI.text = Point.first.ToString();

	}

}

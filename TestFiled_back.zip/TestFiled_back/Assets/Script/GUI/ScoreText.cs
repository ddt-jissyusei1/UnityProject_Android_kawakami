﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

/// <summary>
/// Author:川上　遵
/// 
/// Overview:GameControllerが管理しているScoreを表示するだけ.
/// 
/// Param:
///     Lui:nGUIのTextの制御用
///     LGM:ゲームコントローラーが保持しているデータを参照するための変数。
/// 
///     追記：
///         L表示する文字列を変更するためにstring型の文字列を追加する。
/// 
/// </summary>
[RequireComponent(typeof(NumberManager))]
public class ScoreText : MonoBehaviour {


    NumberManager ui;
    iUIobserver GM;

    Global.Pair<int> tempPoint;//GC減らすため局所変数はこちらで生成しております。

    /// <summary>
    /// Overview:
    ///     Lui,GMの取得。
    /// </summary>
	void Start ()
    {
        ui = GetComponent<NumberManager>();
        GM = FindObjectOfType<GameController>();
    }
	
    /// <summary>
    /// Overview:
    ///     LGameControllerオブジェクトから現在のスコアをもらい表示する。
    /// </summary>
	void Update ()
    {
        tempPoint = GM.GetScore();
        ui.value = (uint)tempPoint.first;
    }
}

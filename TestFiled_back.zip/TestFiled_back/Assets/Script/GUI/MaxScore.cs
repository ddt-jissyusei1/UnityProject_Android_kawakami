﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(NumberManager))]
public class MaxScore : MonoBehaviour {

    NumberManager ui;
    iUIobserver GM;
    
	void Start ()
    {
        ui = GetComponent<NumberManager>();
        GM = FindObjectOfType<GameController>();
        var point = GM.GetScore();
        ui.value = (uint)point.second;
    }
	
}

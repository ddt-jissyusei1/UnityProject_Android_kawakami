﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// タコメーターの動きのスクリプト
/// </summary>
public class TachoMeter : MonoBehaviour
{


    [SerializeField]
    float value;                    //数値
    Quaternion rotation;            //回転量
    [SerializeField]
    string hand = DEFAULT_HAND_NAME;//短い針

    private GameObject _chiled;     //子オブジェクト操作用
    iUIobserver gameController;     //ゲームコントローラー取得
    int currentPoint;               //時間が変動したかどうか調べる.

    void Start()
    {
        gameController = FindObjectOfType<GameController>();
        var n = gameController.GetTimers().second;
        currentPoint = 0;

        Initlize(n);
    }

    void Update()
    {
        int point = (int)gameController.GetTimers().first.seccond;
        //一致していないとき動作する。
        if (currentPoint != point)
        {
            currentPoint = point;
            ROTATION();
        }
    }



    /// <summary>
    /// 初期化処理
    /// @param1:何秒かを指定
    /// @note:回転量の初期化及び針の位置の初期化
    /// </summary>
    void Initlize(float velocity)
    {
        value = velocity;

        var n = value - METER_REFERENCE_VALUE;//誤差を調べる
        //誤差分回転量を変更する。
        rotation = new Quaternion(0, 0, 1.0f, METER_REFERENCE_RADIAN + (METER_CHANGE_VALUE * n));


        _chiled = transform.FindChild(hand).gameObject;
        _chiled.transform.rotation = INITILIZE_ROTATION;
    }

    /// <summary>
    /// 回転とvalue値を変化
    /// </summary>
    void ROTATION()
    {
        _chiled.transform.rotation *= rotation;
        --value;
    }




    /*==============================================================
     ====================      定数宣言        ======================
     ===============================================================*/
    private static readonly float MAX_ROTATION                  = 240; //メーターが４の時の針の回転。
    private static readonly float MIN_ROTATION                  = 0;     //メーターが0の時の針の回転
    private static readonly string DEFAULT_HAND_NAME            = "FrontImage ";
    private static readonly Quaternion INITILIZE_ROTATION       = new Quaternion(0, 0, -0.6f, -0.8f);
    private static readonly float METER_REFERENCE_VALUE         = 100.0f;
    private static readonly float METER_REFERENCE_RADIAN        = 40.0f;
    private static readonly float METER_CHANGE_VALUE            = 0.4f;

}

﻿using UnityEngine;
using UnityEngine.UI;
/// <summary>
/// ボタンのサウンド再生用（SEのみ）
/// 　　サウンドマネージャーから
/// 　　サウンドの再生を登録するだけ
/// 　　numberSEはインスペクタービューで操作
/// </summary>
/// 
[SerializeField]
public class ButtonSounde : MonoBehaviour
{

    [SerializeField]
    private int numberSE;//何番目のSEを鳴らすか
    private Button button;
   


	void Start ()
    {
        //ボタンの制御用にキャッシュ
        button = GetComponent<Button>();
        //サウンドマネージャーをキャッシュ
        var play = FindObjectOfType<SoundeManger>();
        //イベント登録
        button.onClick.AddListener(() => play.onPlaySE(numberSE));
	}
	

}

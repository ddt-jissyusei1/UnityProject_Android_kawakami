﻿using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Author:川上　遵
/// 
/// Overview:
///     LGameControllerの時間情報を表示する。
///     
///　Param:
///　    LGM:GameControllerからの情報参照用
///　    LUI:表示されるテキストの操作を行う。
/// </summary>
[RequireComponent(typeof(Text))]
public class ResultTime : MonoBehaviour
{
    

	void Start ()
    {
        var GMPair = FindObjectOfType<GameController>().GetTimers();
       
        Text UI = GetComponent<Text>();

        var time = GMPair.first;

        UI.text =  time.seccond + "秒";

    }
	


}

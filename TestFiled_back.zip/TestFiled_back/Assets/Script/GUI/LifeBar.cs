﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;


/// <summary>
/// ライフバーの色をグラデーションをする。
/// 
/// 実際に色を変えるオブジェクトにセットする。
/// (Imageの色を変える。)
/// 
/// </summary>
public class LifeBar : MonoBehaviour
{
    [SerializeField]
    private Slider   slider;    //inspector上でセットする。
    private Image     image;    //色を変えるターゲット
    [SerializeField]
    private Color    LimitColor;//何色に変色させるのか

    private static readonly float  MAX = 100;     

	void Start ()
    {
        image = GetComponent<Image>();
         
	}
	

	void Update ()
    {
        var impact = slider.value / slider.maxValue * MAX ;

        var ncolor = ((MAX - impact) * 0.01f);

        if(ncolor > 0.7f)
        image.color = LimitColor * ncolor;
	}
}

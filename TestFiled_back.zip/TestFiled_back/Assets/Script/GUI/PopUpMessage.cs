﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System;

namespace Menu
{

   public interface iPopUpWindow
    {
        void SetManager(iSimpleWindow manager);
    }

    /// <summary>
    /// ゲームの説明文の処理。
    /// 使っていないけど
    /// せっかく作ったから残しました。
    /// </summary>
    public class PopUpMessage : MonoBehaviour,iPopUpWindow
    {

        iSimpleWindow createManager;
        [SerializeField]
        Button cancelbutton;        //戻るボタン
        [SerializeField]
        Button Switch;              //切り替えボタン
        RawImage switchImage;       //切り替えボタンのイメージを操作。

        [SerializeField]
        GameObject[] uiContent;    //パネル状に表示するコンテンツ


        private static readonly Vector2 UVrectPosition  = new Vector2(0, 0.26f);    //コンテンツ２という表示座標
        private static readonly Vector2 UVrectPosition2 = new Vector2(0, 0.72f);    //コンテンツ１という表示座標
        private static readonly Vector2 UVrectScale     = new Vector2(1, 0.19f);    //画像のスケーリング
        private static readonly Rect CONTENT_ONE = new Rect(UVrectPosition, UVrectScale);
        private static readonly Rect CONTENT_TWO = new Rect(UVrectPosition2, UVrectScale);

        private static readonly int contentOne = 0;
        private static readonly int contentTwo = 1;
        private int switchValue;            //切り替え用
        private delegate void voidPointer();//関数ポインタ
        private voidPointer[] ActivePointer;//関数ポインタ配列[switchValue]で切り替えを行う。

        public void Start()
        {


            //スイッチの初期化
            switchImage = Switch.GetComponent<RawImage>();
            switchImage.uvRect = CONTENT_ONE;

            //コンテンツの初期化
            uiContent[contentOne].SetActive(true);
            uiContent[contentTwo].SetActive(false);

            //関数ポインタの初期化
            ActivePointer = new voidPointer[2];
            ActivePointer[contentOne] = onOneActive;
            ActivePointer[contentTwo] = onTwoActive;

            cancelbutton.onClick.AddListener(() => Cancel());//戻るボタンのイベント登録
            Switch.onClick.AddListener(() => SWITCH());//切り替えボタンのイベント登録

        }

        void SWITCH()
        { 
            ActivePointer[switchValue]();
        }

        //コンテンツ１表示　２は非表示
        void onOneActive()
        {
            uiContent[contentTwo].SetActive(true);
            uiContent[contentOne].SetActive(false);

            switchImage.uvRect = CONTENT_TWO;
            switchValue = contentTwo;//次の切り替えの設定。
        }

        //コンテンツ2表示　1は非表示
        void onTwoActive()
        {
            uiContent[contentOne].SetActive(true);
            uiContent[contentTwo].SetActive(false);
            switchValue = contentOne;
            switchImage.uvRect = CONTENT_ONE;
        }

        /// <summary>
        /// 戻るが押された時の処理
        /// 死ぬ。
        /// </summary>
        public void Cancel()
        {
            createManager.CreateFrag = false;
            Destroy(gameObject);
        }
        /// <summary>
        /// クリエイターを登録
        /// </summary>
        /// <param name="manager"></param>
        public void SetManager(iSimpleWindow manager)
        {
            createManager = manager;
        }
    }


}
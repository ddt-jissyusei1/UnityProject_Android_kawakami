﻿using UnityEngine;
using System.Collections;
using System;


/// <summary>
/// Overview:
///     Canvasのアクティブ・非アクティブ状態の管理を行う。
/// </summary>
[RequireComponent(typeof(Canvas))]
public class CanvasController : MonoBehaviour,iActive
{
    Canvas canvas;

    //Canvasをとってきて
    //非表示にする。
    void Start()
    {
        canvas = GetComponent<Canvas>();
        FindObjectOfType<GameController>().actives.Add(this);
        canvas.enabled = false;
    }
    /// <summary>
    /// セッタゲッタ
    /// </summary>
    public bool ACTIVE
    {
        get
        {
            return this.enabled;
        }

        set
        {
          
            if (canvas != null)
                canvas.enabled = value;
            
        }
    }
    
}

﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;


/// <summary>
/// Please TouchのUIのアニメーション。
/// </summary>
[RequireComponent(typeof(RawImage))]
public class PleaseTouch : MonoBehaviour
{

    RawImage image;//画像操作用。
    IEnumerator anime;//コルーチン
	void Start ()
    {
        image = GetComponent<RawImage>();
        anime = Flash(0.04f);
        StartCoroutine(anime);
	}
	


    /// <summary>
    /// 画像のアルファ値をいじる。
    /// 第一引数：アルファ値の変動量。
    IEnumerator Flash(float change)
    {
        //imageのカラーを取得
        float x = 0.0f;
        float alpah = 0.0f;

        while(true)
        {
            alpah = Mathf.Cos(x);
            image.color =new Color(image.color.r, image.color.g, image.color.b, alpah);
            x+= change;
            x = x % 1.5f;//簡易まるめ処理
            yield return null;
        }
        
    }

}

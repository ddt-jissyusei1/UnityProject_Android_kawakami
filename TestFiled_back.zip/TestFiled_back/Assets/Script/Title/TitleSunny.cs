﻿using UnityEngine;
using System.Collections;


/// <summary>
/// Author:川上　遵
/// 
/// Overview:
///     Lタイトル用太陽(ターゲットを見る)
///     
/// </summary>
public class TitleSunny : MonoBehaviour {

    [SerializeField]
    private float       speed;    //回転速度
    [SerializeField]
    private Vector3     translate;//回転軸
    [SerializeField]
    private float       Angle;    //アングル
	

	void Update ()
    {
        //０～１で丸める
        Mathf.Clamp01(translate.x);
        Mathf.Clamp01(translate.y);
        Mathf.Clamp01(translate.z);

        Angle += Time.deltaTime;

        transform.localRotation = Quaternion.AngleAxis(Angle*  speed, translate);

	}
}

﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

/// <summary>
/// 画像で数値を出力
/// 桁数はinspectorビューで設定をしてください
/// 設定された以上の桁数は無視します。
/// </summary>
class NumberManager : MonoBehaviour
{
    [SerializeField]
    List<RawImage> imageSrc;//表示する桁
    [SerializeField]
    Texture resroce;        //画像リソース
    //[SerializeField]
    //GameObject IMAGE_OUTPUT_OBJECT_PREFAB;//表示するオブジェクトのプレハブ
    [SerializeField]
    public uint value;      //符号なし


    readonly Rect slice = new Rect(X, Y, W, H);//初期化用
    Rect temp;  //一時的用
    int i;      //update関数のループ用

    ///////インスタンス生成用////////////
    //Vector3 POSITION;       //移動
    //Quaternion ROTATION;    //回転

    public void Start()
    {

        //各子オブジェクトを初期化
        foreach (var i in imageSrc)
        {
            i.texture = resroce;
            i.uvRect = slice;

        }

    }

    /// <summary>
    /// 確保したimageSrc分チェックする。
    /// </summary>
    /// 
    public void Update()
    {
        for (i = 0; i < imageSrc.Count; i++)
        {
            var num = num_count(i);
            number_update(i, num);
        }
    }

    /// <summary>
    /// digit番目の数値をnumに更新する
    /// </summary>
    /// <param name="digit">何番目の桁</param>
    /// <param name="num">表示する数値</param>
    void number_update(int digit, int num)
    {
        temp = new Rect(X * num, Y, W, H);
        imageSrc[digit].uvRect = temp;
    }

    /// <summary>
    /// 自身のvalue値を分解する
    /// </summary>
    /// <param name="digit">何番目の桁</param>
    /// <returns></returns>
    int num_count(int digit)
    {
        //文字列変換
        string nums = value.ToString().Substring(digit,1);

        //int型変換
        int result = int.Parse(nums);

        return result;
    }

    /// <summary>今回使わない
    /// 表示するオブジェクトを追加する.
    /// 左に増える
    /// </summary>
    //void AddNumberObject()
    //{
    //    var gameObject = (GameObject)Instantiate(IMAGE_OUTPUT_OBJECT_PREFAB, POSITION, ROTATION);
    //    transform.parent = gameObject.transform;
    //
    //    imageSrc.Add(gameObject.GetComponent<RawImage>());//イメージソースを追加
    //}

    /// <summary>
    /// 引数の値がimageSrcとvalue値より大きければtrue;
    /// </summary>
    /// <param name="digit"></param>
    /// <returns></returns>
    bool IsOver(int digit)
    {
        if (digit <= 0) return false;
        int leng = 1 * ((int)Math.Pow(10, digit));
        return leng > value || digit > imageSrc.Count;
    }



    const float H = 1f;
    const float W = 0.1f;
    const float X = 0.09f;
    const float Y = 0f;


}


﻿using UnityEngine;
using System.Collections;
using UnityEngine.Events;
using Global;
using UnityStandardAssets.CrossPlatformInput;
using System;




/// <summary>
/// Author：川上　遵
/// カメラオブジェクト
/// 
/// SerializeFieldはインスペクタービューで操作。
/// 
/// Method：
///     LStart()     :最初の視点の設定。
///     LLateUpdate():Unityのイベント関数ターゲットの方向を向くだけ。
///     LOnChange()  :状態変更イベント
/// </summary>
public class GameView : MonoBehaviour,CameraController,iEventController
{


    private bool isDorryMove = false;        //ドリー操作が動作しているのかどうか
    [SerializeField]
    private Transform DorryTarget;           //ドリー時のターゲット

    [SerializeField]//カメラの位置リスト
    private Transform[] positionList = new Transform[playupdateCount];
    [SerializeField]//カメラの注視点リスト
    private Transform[] targetList   = new Transform[playupdateCount];
    private State playCamerState;           //位置の状態を知らせるフラグ

    

    private VoidMethodPointer pointer;      //関数ポインタ（更新処理のポインタ)
    [SerializeField][Range(0,2)]
    int updateIndex;                        //現在の更新状態。

    //更新処理の切り替え用のげったせった
    public int Index
    {
        get
        {
            return updateIndex;
        }

        set
        {
            updateIndex = value;
        }
    }



	void Start ()
    {
        playCamerState = new one();//最初は三人称視点
        pointer        = new VoidMethodPointer(playupdateCount);
        
        //更新処理の関数を呼び出すためのインデックス
        updateIndex = 0;

        //更新処理の関数のセットアップ
        pointer.MethodSET(startUpdateindex, OnStartScene);
        pointer.MethodSET(playUpdateindex,  OnPlayScene);
        pointer.MethodSET(endUpdateindex,   OnEndScene);
    }
	
	void LateUpdate()
    {
        pointer.Run(updateIndex);
	}

    /// <summary>
    /// 俯瞰視点とTPSの切り替え
    /// </summary>
    public void OnChange()
    {
        playCamerState = playCamerState.Next();
    }
    
    /// <summary>
    /// スタート中のカメラ処理
    /// </summary>
    public void OnStartScene()
    {
        var relativePos = targetList[Mather].position - transform.position;
        var rotation = Quaternion.LookRotation(relativePos);
        var current = transform.localRotation;
        transform.rotation = Quaternion.Lerp(current, rotation, Time.deltaTime * StartSceneViewSpeed );
    }

    /// <summary>
    /// プレイ中のカメラ処理
    /// </summary>
    public void OnPlayScene()
    {
        if (isDorryMove) return;

        var relativePos = targetList[playCamerState.value].position - transform.position;
        var rotation = Quaternion.LookRotation(relativePos);
        var current = transform.localRotation;

        transform.rotation = Quaternion.Lerp(current, rotation, Time.deltaTime * PlaySceneViewSpeed);

        transform.position = Vector3.Lerp
        (
            transform.position,
            positionList[playCamerState.value].position,
            Time.deltaTime * PlaySceneSpeed
        );
    }

    /// <summary>
    /// 終了中のカメラ処理。
    /// </summary>
    public void OnEndScene()
    {
        var relativePos = targetList[Mather].position - transform.position;
        var rotation = Quaternion.LookRotation(relativePos);
        var current = transform.localRotation;

        transform.rotation = Quaternion.Lerp(current, rotation, Time.deltaTime * EndSceneViewSpeed);


        transform.position = Vector3.Lerp
        (
            transform.position,
            positionList[Mather].position,
            Time.deltaTime * PlaySceneSpeed
        );
    }

    /// <summary>
    /// ドリーイン・ドリーアウトの移動撮影をする。
    /// runTime秒まで行う。
    /// </summary>
    /// <param name="isRunning"></param>
    /// <returns></returns>
    IEnumerator DorryMove(float runTime,float speed,Vector3 distance,Transform target,UnityAction<bool> runningBack)
    {

        float result;
        StopWatch timeWatch = new StopWatch();

        float half      = runTime / 2;
        var moveDi      = distance;

        //時間計測開始
        timeWatch.onStart();

        //開始合図
        runningBack(true);
        
        //所定の位置まで移動
        do
        {

            timeWatch.onStop();
            result = timeWatch.onResult();

            transform.LookAt(target);

            transform.Translate(moveDi * (speed * result));

            yield return null;

        } while (half >= result);

        
        timeWatch.onStart();

        //何もしない。
        do
        {
            timeWatch.onStop();
            result = timeWatch.onResult();

            yield return null;

        } while (half >= result);

        //終了合図
        runningBack(false);


    }

    /// <summary>
    /// ドリールーチンを呼び出す。
    /// </summary>
    public void ArmEvnet()
    {
        if (isDorryMove) return;
        StartCoroutine(DorryMove(DorryMoveTime, DorryMoveSpead, DorryDistance, DorryTarget,frag => isDorryMove = frag));
    }

    /// <summary>
    /// プレイヤーの操作
    /// </summary>
    public void Event()
    {
        OnChange();
    }

    public void Dorry(float MoveTime, float MoveSpeed, Vector3 distance, Transform target)
    {
        StartCoroutine(DorryMove(MoveTime, MoveSpeed, distance, target, frag => isDorryMove = frag));
    }


    public void Move(Vector3 position,Vector3 offset)
    {
        transform.position = Vector3.Lerp
       (
           transform.position,
           position + offset,
           Time.deltaTime * StartSceneSpeed
       );
    }



    //適当なオブジェクトに入れて置けばよかった。

    public static readonly int BardsView = 0;       //俯瞰視点
    public static readonly int TPS = 1;             //三人称視点
    public static readonly int Mather = 2;          //ムービ時見ている視点（matherにしているのは当初マザーを見る予定だったから)

    public static readonly int playupdateCount = 3; //実際の更新処理の個数。

    public static readonly int startUpdateindex = 0;//スタートシーンの更新処理のインデックス。
    public static readonly int playUpdateindex = 1; //プレイシーンの更新処理のインデックス。
    public static readonly int endUpdateindex = 2;  //終了シーンの更新処理のインデックス。

    public static readonly float StartSceneSpeed = 0.3f;//スタートシーン時のカメラの移動速度
    public static readonly float PlaySceneSpeed = 2;    //プレイシーン時の移動速度
    public static readonly float EndSceneSpeed = 10;    //終了シーン時の移動速度

    public static readonly float StartSceneViewSpeed = 5;   //カメラが注視点に向く速度
    public static readonly float PlaySceneViewSpeed = 5;    //カメラが注視点に向く速度
    public static readonly float EndSceneViewSpeed = 5;     //カメラが注視点に向く速度

    public static readonly float DorryMoveTime = 2f;   //ズームの時間
    public static readonly float DorryMoveSpead = 0.1f;//ズームの速度
    public static readonly Vector3 DorryDistance = new Vector3(1f, 0.0f, 0.7f);//動きかたを指定
}

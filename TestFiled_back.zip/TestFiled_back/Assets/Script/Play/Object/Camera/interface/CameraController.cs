﻿using UnityEngine;

/// <summary>
/// ゲームコントローラーが持つ用
/// 　ゲームコントローラーでカメラの更新処理の切り替えを行えるようにする
/// </summary>
[SerializeField]
interface CameraController
{
    int Index
    {
        set;
        get;
    }

    /// <summary>
    /// アームがキャッチするイベントの際のカメラ動作。
    /// </summary>
    void ArmEvnet();

    /// <summary>
    /// ドリー操作
    /// </summary>
    void Dorry(float MoveTime,float MoveSpeed,Vector3 distance, Transform target);

    /// <summary>
    /// カメラの移動
    /// </summary>
    /// <param name="position">移動先</param>
    void Move(Vector3 position,Vector3 offset);
}


﻿using UnityEngine;

/// <summary>
/// マザーシップとマザーシップのJointの窓口.
/// 
/// </summary>
[SerializeField]
public interface MatherStatus
{
     MatherShipMove.ActionMode  IsAction();
     MatherShipMove.JointMather IsJoint();
}

/// <summary>
/// 母艦とプレイヤーの接続処理
/// 補間のステータスがOnになればプレイヤーとの接続処理を開始
/// OFFになれば解除。
/// </summary>
public class MatherJoint : MonoBehaviour
{
    private MatherStatus               matherStatus;  //マザーシップの状態.
    private MatherShipMove.JointMather currentStatus; //マザーシップのジョイント
    private FixedJoint                 Joint;         //Joint制御用。
    [SerializeField]
    private bool                       onceFrag;      //Joint生成時に複数生成抑える用。

    public  MatherStatus Mather                       //マザーシップが登録する用。
    {
        set { matherStatus = value; }
    }


    /// <summary>
    /// 初期化
    /// </summary>
	void Start ()
    {
        if (matherStatus == null) matherStatus = FindObjectOfType<MatherShipMove>();
        currentStatus = matherStatus.IsJoint();
        onceFrag = false;
	}
	
    /// <summary>
    /// 状態情報がOFFであれば放す処理を行う。
    /// </summary>
	void Update ()
    {
        //JointMather.OFFになったら外す。
        currentStatus = matherStatus.IsJoint();

        if (currentStatus == MatherShipMove.JointMather.Off)
        {
            onceFrag = false;
            Destroy(Joint);
        }
        
    }

    /// <summary>
    /// 当たったオブジェクトがプレイヤー
    /// かつ
    /// Jointがonになったらくっつく
    /// かつ
    /// onceFragが立っていなければ
    /// くっつく物理演算処理つける。
    /// </summary>
    /// <param name="collider"></param>
    void OnTriggerStay(Collider collider)
    {
       if(collider.tag == Global.sTags.Player
           && !onceFrag
           && currentStatus == MatherShipMove.JointMather.On)
       {
           onceFrag = true;
       
           CreateJoint(ref collider);
       
       }

    }
    

    /// <summary>
    /// Overview:
    ///     LJointコンポーネントを作成、設定を行う。
    /// </summary>
    /// <param name="collider"></param>
    private void CreateJoint(ref Collider collider)
    {
        Joint               = gameObject.AddComponent<FixedJoint>();
        Joint.connectedBody = collider.GetComponent<Rigidbody>();
        collider = null;//使ったら空っぽにする。
    }
}

﻿using UnityEngine;
using UnityEngine.Events;
using System.Collections.Generic;
using Global;
using System.Collections;
using System;

/// <summary>
/// Author:川上　遵
/// 
/// Overview:
///     マザーシップの制御管理オブジェクト。
/// </summary>
public class MatherShipMove : MonoBehaviour, iMatherEventController
{
    //マザーシップの状態を種類。
    public enum ActionMode
    {
        Start = 0,  //スタートシーン
        Play = 1,   //プレイシーン
        End = 2,    //エンドシーン
    };
    //マザーシップのジョイントの状態の種類
    public enum JointMather
    {
        On,
        Off
    }
    //マザーシップのシーン処理。
    [System.Serializable]
    public struct Action
    {
        public CoroutineMoveData       FirstMove;   //移動処理
        public CoroutineMoveData       SccondeMove; //移動処理
        public CoroutineRotationData   Rotation;    //回転
        public JointMather             Joint;       //Joint制御用。On,OFF
    }



    [SerializeField]
    private ActionMode        mode;             //現在のモード。
    [SerializeField]          
    private JointMather       jointStatus;      //Jointの状態。
    private bool              EndScene;         //エンドシーン(エンドシーン２）を一回しか呼ばないフラグ。このフラグが立っていれば終了イベント２を呼び出せる。
   
    //スタートシーンおよびエンドシーンのアクションリスト的な奴。
    private Action            startAction;      //登場イベント
    private Action            endAction;        //終了イベント２

    private CoroutineMoveData advanceEndAcetion;//終了イベント１
    private IEnumerator       advanceEndEvent;  //終了イベント１の処理を格納。(終了する際(戻り値の値を)に必要)
    private GameObject        advanceSubFire;   //終了イベント１が強制終了した際のエフェクトの後始末用。

    [SerializeField]
    private GameObject  MainFire;       //進む際に生成される炎のエフェクト。
    [SerializeField]
    private GameObject  SubFire;        //離着陸時に生成される炎のエフェクト。
    [SerializeField]
    private MatherJoint FixedJoinT;     //Jointオブジェクトを渡す。
    [SerializeField]
    private Transform MainFirePositon;  //メインブースターのポジション

    
    //各初期化
    void Start()
    {
        mode                = ActionMode.Start;
        jointStatus         = JointMather.On;
        EndScene            = true;
        FixedJoinT.Mather   = this;//自分自身を登録。
       

        //スタートシーン用
        startAction.FirstMove.SET  (Vector3.forward, 0.3f, MatherShipAnimationTimes.StartMoveTime,MatherShipAnimationTimes.StartMoveWaitTime);
        startAction.SccondeMove.SET(Vector3.down, 0.05f, MatherShipAnimationTimes.StartDownTime,MatherShipAnimationTimes.StartDownWaitTime);
        startAction.Rotation.SET   (Vector3.up, -0.6f, MatherShipAnimationTimes.StartRotationTime, MatherShipAnimationTimes.StartRotationWaitTime);
        startAction.Joint = JointMather.Off;

        ///エンドシーン用
        endAction.FirstMove.SET  (Vector3.forward, 0.2f, MatherShipAnimationTimes.EndMoveTime, MatherShipAnimationTimes.EndMoveWaitTime);
        endAction.SccondeMove.SET(Vector3.up, 0.02f, MatherShipAnimationTimes.EndUpTime, MatherShipAnimationTimes.EndUpWaitTime);
        endAction.Rotation.SET   (Vector3.up, 0.02f, MatherShipAnimationTimes.EndRotationTime,MatherShipAnimationTimes.EndRotationWaitTime);
        endAction.Joint = JointMather.On;

        //エンドシーンの前のアニメーション用の処理。
        //下に0.02づつAdvancedDowTime秒進む。
        advanceEndAcetion.SET(Vector3.down, 0.03f, MatherShipAnimationTimes.AdvancedDowTime);
       
        //処理を格納。呼び出してはいない。
        advanceEndEvent = onAccelerationMoveUpdate(advanceEndAcetion, frag => advanceEndAcetion.isRunning = frag,pointer => advanceSubFire = pointer);

        onStartEvent();
      
    }


    /// <summary>
    /// 
    /// スタートシーン以外は処理を行わない。
    /// 
    /// スタートシーンが終わったら
    /// UIとcameraの状態を変異させる。
    /// 
    /// </summary>
    void Update()
    {

        //終了イベント１が終了し、エンドシーンフラグが立っていれば呼び出し。
        //ジョイントの状態が終了イベント１（下がる）が終了時にでONになるのでジョイントのステートを見ている。
        if (mode == ActionMode.End && !advanceEndAcetion.isRunning && EndScene)
        { onEndNextEvent(); EndScene = false; }

        //スタートシーン以外は処理を行わない。
        if (mode != ActionMode.Start) return;

        //各コルーチンのフラグがすべてfalseだったら
        bool startFlag = startAction.FirstMove.isRunning || startAction.SccondeMove.isRunning || startAction.Rotation.isRunning;

        //スタートシーンが終わったら。
        if (!startFlag)
        {
            mode = ActionMode.Play;
        }

    }



    /// <summary>
    /// 床と当たったら
    /// 終了イベント（プレイヤーを拾う）を強制終了し
    /// 終了イベント２を呼び出す。
    /// </summary>
    /// <param name="col"></param>
    void OnTriggerEnter(Collider col)
    {
        if (col.tag == sTags.Filed && EndScene)
        {
            

            //終了イベント１を強制終了
            //Updateで呼び出されないようにフラグを折る。
            EndScene = false;
            StopCoroutine(advanceEndEvent);
            DestroyBooster(ref advanceSubFire);
            StartCoroutine(onChangeJoint(JointMather.On/*, startAction.SccondeMove.runninngTime + startAction.FirstMove.runninngTime*/));


            //終了イベント２をスタート
            onEndNextEvent();

        }
    }

    
    /// <summary>
    /// 移動のコルーチン
    /// WaitForSeconds秒後メインブースター点火
    /// 終わった後に消化。
    /// </summary>
    /// <param name="data">移動に必要な情報が格納されている。</param>
    /// <param name="callback">コルーチンが動いているならtrue</param>
    /// <returns></returns>
    IEnumerator onAccelerationMoveUpdate(CoroutineMoveData data,UnityAction<bool> callback)
    {
        float moveTime = 0;
        //開始合図
        callback(true);
        //速度減速用
        var a = data.speed / data.runninngTime;
        //キャッシング
        var vector = data.vector;

        //GC作用する～
        yield return new WaitForSeconds(data.WaitTime);

        //ブースター点火
        GameObject tempObject = null;
        //前進であれば
        if (vector == Vector3.forward) CreateMainBooster(ref tempObject);
        else CreateSubBooster(ref tempObject);

       
        do
        {
            moveTime += Time.deltaTime;

            transform.Translate(vector * (data.speed - a * moveTime));
            
            yield return null;

            
        } while (moveTime < data.runninngTime);

        //ブースター消化
        DestroyBooster(ref tempObject);
        //終了合図
        callback(false);

        
    }
   
    /// <summary>
    /// 上の拡張版（一行追加のみ）
    /// 引数にはブースターのポインターを受け取る変数を用意すれば
    /// 強制終了した際にも後始末ができる。
    /// </summary>
    /// <param name="data"></param>
    /// <param name="callback"></param>
    /// <param name="effectBack">ブースターポインター</param>
    /// <returns></returns>
    IEnumerator onAccelerationMoveUpdate(CoroutineMoveData data, UnityAction<bool> callback,UnityAction<GameObject> effectBack)
    {
        //float moveTime = 0;
        float ResultTime;
        StopWatch timeWatch = new StopWatch();

        //時間計測開始
        timeWatch.onStart();

        //開始合図
        callback(true);
        //速度減速用
        var a = data.speed / data.runninngTime;
        //キャッシング
        var vector = data.vector;

        yield return new WaitForSeconds(data.WaitTime);

        //ブースター点火
        GameObject tempObject = null;
        //前進であれば
        if (vector == Vector3.forward) CreateMainBooster(ref tempObject);
        else CreateSubBooster(ref tempObject);

        effectBack(tempObject);//ブースターのポインター返す。Destroyに使うため。

        do
        {

            //時間計測止める。
            timeWatch.onStop();
            //始めた時間と止めた時間の計算
            ResultTime = timeWatch.onResult();

            transform.Translate(vector * (data.speed - a * ResultTime));

            yield return null;


        } while (ResultTime < data.runninngTime);

        //ブースター消化
        DestroyBooster(ref tempObject);
        //終了合図
        callback(false);


    }
    


    /// <summary>
    /// 回転のコルーチン
    /// </summary>
    /// <param name="data">回転に必要な情報が格納されている。</param>
    /// <param name="callback">コルーチンがうごいているならtrue</param>
    /// <returns></returns>
    IEnumerator onRotationUpdate(CoroutineRotationData data,UnityAction<bool> callback)
    {
        float resutlTime;
        StopWatch timeWatich = new StopWatch();
        
       //呼び出された時点で開始されているという
        callback(true);

        //指定時間まで待つ。
        yield return new WaitForSeconds(data.WaitTime);

        //時間計測開始
        timeWatich.onStart();

        do
        {
      
            //計測終了
            timeWatich.onStop();

            resutlTime = timeWatich.onResult();


            transform.localRotation =transform.localRotation * Quaternion.AngleAxis(resutlTime * data.speed, data.axis);

            yield return null;

        } while (resutlTime < data.runninngTime);


        callback(false);

    }
    
    /// <summary>
    /// Jointの制御
    /// 　WaitTIme後にvalueにJointのステートが変わるコルーチン
    /// </summary>
    /// <param name="value">制御ステータス</param>
    /// <param name="WaitTime"></param>
    /// <returns></returns>
    IEnumerator onChangeJoint(JointMather value,float WaitTime = 0)
    {

        yield return new WaitForSeconds(WaitTime);

        jointStatus = value;

        yield return null;

    }





    //現在の自分自身の状態。
    public ActionMode IsAction()
    {
        return mode;
    }
    //現在のジョイントの状態
    public JointMather IsJoint()
    {
        return jointStatus;
    }

    /// <summary>
    /// ここから先の引数で
    /// UnityActionの特殊な書き方をしていますので注意が必要。
    ///     r => ○○ = r;
    ///     r:callbackで来るvalue値（適当）
    ///     ○○:代入先の変数名。
    /// </summary>

    //スタートイベント
    private void onStartEvent()
    {
        mode = ActionMode.Start;
        StartCoroutine(onAccelerationMoveUpdate(startAction.FirstMove, r => startAction.FirstMove.isRunning = r));
        StartCoroutine(onAccelerationMoveUpdate(startAction.SccondeMove, r => startAction.SccondeMove.isRunning = r));
        StartCoroutine(onRotationUpdate(startAction.Rotation, r => startAction.Rotation.isRunning = r));
        StartCoroutine(onChangeJoint(startAction.Joint, startAction.SccondeMove.runninngTime + startAction.FirstMove.runninngTime));
    }

    //終了イベント
    private void onEndEvent()
    {
        mode = ActionMode.End;
        

        //呼び出し。
        StartCoroutine(advanceEndEvent);

    }

    //終了イベント２
    private void onEndNextEvent()
    {
        StartCoroutine(onAccelerationMoveUpdate(endAction.FirstMove, r => endAction.FirstMove.isRunning = r));
        StartCoroutine(onRotationUpdate(endAction.Rotation, r => endAction.Rotation.isRunning = r));
        StartCoroutine(onAccelerationMoveUpdate(endAction.SccondeMove, r => endAction.SccondeMove.isRunning = r));
    }

    //イベント関数を呼び出すための関数。
    //StartCoroutineを呼び出す関数を直接呼び出せないためｌ
    public void Event()
    {
        onEndEvent();
    }

    /// ブースターの作成
    //メインブースター
    private void CreateMainBooster(ref GameObject booster)
    {
        booster = (GameObject)Instantiate(MainFire, MainFirePositon.position, Quaternion.identity);
        booster.transform.parent = transform;

    }
    //サブブースター
    private void CreateSubBooster(ref GameObject booster)
    {
        booster = (GameObject)Instantiate(SubFire, transform.localPosition, transform.localRotation);
        booster.transform.parent = transform;

    }
    //ブースターエフェクト削除。
    private void DestroyBooster(ref GameObject booster)
    {
        Destroy(booster);
    }

}

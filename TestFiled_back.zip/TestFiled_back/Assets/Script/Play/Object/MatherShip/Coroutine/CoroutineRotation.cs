﻿using UnityEngine;
using System;
using System.Collections;


/// <summary>
/// 回転処理(コルーチン)のデータ保持
/// </summary>
/// 
[Serializable]
public struct CoroutineRotationData
{
    
    public bool isRunning;    //処理が終わったかどうか
    public Vector3 axis;      //どの軸に対しての回転か
    public float WaitTime;    //処理の開始を遅らせる。
    public float speed;       //どのくらいの速度で回転するのか
    public float runninngTime;//処理時間

    public void SET(Vector3 distance, float rotationSpeed, float methodRunningTime,float waitTime = 0.0f)
    {
        isRunning = false;
        axis = distance;
        speed = rotationSpeed;
        WaitTime = waitTime;
        runninngTime = methodRunningTime;
    }

}

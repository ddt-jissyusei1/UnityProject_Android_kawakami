﻿using UnityEngine;
using System;

/// <summary>
/// 移動処理（コルーチン）のデータ保持
/// </summary>
[System.Serializable]
public struct CoroutineMoveData
{
   
    public bool     isRunning;      //処理が終わったかどうか
    public Vector3  vector;         //移動方向。Vector3.up等・・・
    public float    WaitTime;       //処理の開始時間
    public float    speed;          //移動速度
    public float    runninngTime;   //処理時間

    public void SET(Vector3 distance,float moveSpeed,float methodRunningTime,float waitTime  = 0.0f)
    {
        isRunning    = false;
        vector       = distance;
        speed        = moveSpeed;
        WaitTime     = waitTime;
        runninngTime = methodRunningTime;
    }
}

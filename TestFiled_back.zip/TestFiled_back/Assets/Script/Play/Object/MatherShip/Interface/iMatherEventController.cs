﻿/// <summary>
/// ゲームコントローラーがエンドシーンアクションを呼べる用。
/// </summary>
public interface iMatherEventController:MatherStatus
{
    void Event();
}


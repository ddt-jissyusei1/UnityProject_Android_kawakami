﻿using UnityEngine;

/// <summary>
/// Overview:
///     各マザーシップのアクションのインターフェース。
/// </summary>
public interface iMatherAction  {

    void Initilize();
    void Update();
    void Final();
    void onNext();
}

﻿using UnityEngine;
using System.Collections;
using Global;

/// <summary>
/// Author：川上　遵
/// 鉱石オブジェクト(Oreだった・・)
/// 
/// Method：
///   LStart :各パラメーターの初期化
///   LUpdate :何秒に一回処理するようにしている。理由（ちかちかするため）
/// </summary>

[RequireComponent(typeof(ParticleSystem))]
[RequireComponent(typeof(SphereCollider))]
public class Are : MonoBehaviour
{
    private RayInfo<Ray>    rayInfo;   //Ray情報
    public  Transform       Sunny;     //太陽の位置にRayを飛ばすようの座標(GUI操作用）
    private TimeInfo        timeInfo;  //時間計測用(3秒)
    private SphereCollider  coli;      //あたり判定操作用
    private MeshRenderer    render;    //描画操作用
    private ParticleSystem  particle;  //パーティクルデータ操作用


    /// <summary>
    /// Overview:
    ///     L各種パラメーターの初期化
    /// </summary>
    void Start()
    {

        //各コンポーネントを取得.
        coli        = gameObject.GetComponent<SphereCollider>();
        render = transform.GetComponentInChildren<MeshRenderer>();
        particle    = gameObject.GetComponent<ParticleSystem>();

        //各状態フラグを初期化
        coli.enabled    = true;
        coli.isTrigger  = true;
        render.enabled  = false;
        gameObject.tag = sTags.AreHidden;//Areの属性を変更。
        particle.Stop();

        rayInfo = new RayInfo<Ray>();

        //newしなくてもいいけど。
        timeInfo = new TimeInfo(1.0f);

    }

    /// <summary>
    /// Overview:
    ///     LtimeInfo.TimeLimit分の1回処理を行う。
    ///     LRayをSunnyの方向に飛ばし、あたり判定をチェックする。
    ///     分岐の処理は構造体にしてまとめたかった。    
    /// 
    /// </summary>
    void Update()
    {
        //TimeTask回に一回Updateされる。
        timeInfo.CurrentTime += Time.deltaTime;
        if (timeInfo.TimeLimit >= timeInfo.CurrentTime) return;
        timeInfo.CurrentTime = 0;

        //Rayの方向の更新.
        rayInfo.ray.origin = transform.position + (Vector3.up * 0.5f);//開始位置
        rayInfo.ray.direction = Sunny.position - rayInfo.ray.origin;//方向

        //Rayヒットしたかどうか
        if (Physics.Raycast(rayInfo.ray, out rayInfo.hit))
           Enabled();
        else
           Unenabled();

    }

    /// <summary>
    /// 表示処理
    /// </summary>
    void Enabled()
    {
        render.enabled = true;              //描画有効
        gameObject.tag = sTags.Are;         //Areの属性を変更
        particle.Play();                    //パーティクル実行
    }

    /// <summary>
    /// 非表示処理
    /// </summary>
    void Unenabled()
    {
        render.enabled = false;
        gameObject.tag = sTags.AreHidden;
        particle.Stop();
    }
}

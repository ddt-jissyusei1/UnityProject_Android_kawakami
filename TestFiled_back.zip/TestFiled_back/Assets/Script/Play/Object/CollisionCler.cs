﻿using UnityEngine;


/// <summary>
/// Author:川上　遵
/// コリジョンクリアオブジェクト
/// 
/// Overview:
///     CatchArmオブジェクトの状態がoffになったら特定の座標に呼ばれすぐ死ぬ。
/// 
/// Param:
///     L LifeTime:生命時間
/// </summary>
public class CollisionCler : MonoBehaviour
{
    
    public float LifeTime;
    
    /// <summary>
    /// Overview:
    ///     ・LifeTimeの更新を行い、LifeTimeが0より小さければデストロイ！
    /// </summary>
	void Update ()
    {
        LifeTime -= Time.deltaTime;
        if (LifeTime < 0) Destroy(gameObject);
	}
}

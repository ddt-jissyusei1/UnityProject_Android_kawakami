﻿using UnityEngine;

//ゲームコントローラーを初期化し死ぬ。
 class Refuresh:MonoBehaviour
 {
    void Start()
    {
        //探し出して
        var GameController = FindObjectOfType<GameController>();
        //初期化して
        GameController.Initilize();
        //自殺
        Destroy(gameObject);
    }


 }


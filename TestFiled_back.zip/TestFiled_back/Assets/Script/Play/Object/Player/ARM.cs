﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using Global;


/// <summary>
/// カメラがアームのイベントをとってくる用
/// </summary>
public interface iCameraToArm
{
    void onArmEvent();
}

/// <summary>
/// アーム制御処理。
/// ArmHITが実際にはあたり判定の処理を行っているため
/// ArmHITのタグを変更するようにしている。
/// ArmHITは更新処理の際にタグをこちらからもらうように処理をしている。
/// </summary>
/// 
[RequireComponent(typeof(AudioSource))]
public class ARM : MonoBehaviour,iParts, iArmHITToARM,iEventController
{

    public delegate void CREATE(Vector3 position);//ARMのCreateClearを各ステートオブジェクトに渡す用。

    public enum ARMstate
    {
        ON,
        OFF,
        UP
    }
    [Serializable]//inspectorビューに表示用。
    public class ArmParameter
    {
        public Animator         anim;        //アニメーション制御用。
        public ARMstate         status;      //アームの状態変数。
        public GameObject       gameObject;  //ARM自体のオブジェクト
        public BoxCollider      colllider;   //あたり判定制御用。
        public CREATE           creater;     //CreateClearの呼び出し用。
        public GameController   manager;     //ゲームのポイントの加算用。
        public AudioSource      sound;       //音源。
        public GameObject destroyEffect;     //鉱石が死んだときに放つエフェクト
    }

    //下記の定数はState()で返ってくるそれぞれの値。
    public static readonly int OFF = 0;//OFFの時に帰ってくる値
    public static readonly int ON  = 2;//ONの時に帰ってくる値
    public static readonly int UP  = 1;//UPの時に帰ってくる値

    //下記の定数はスキンメッシュアニメーション時にの遷移で使う文字列。
    //anim.SetBool("")で使います。
    public static readonly string AnimeWaitFlag      = "Non";   //伸ばした時に初期時に戻るための文字列。これのフラグをtrueにして。
    public static readonly string AnimeUpFlag        = "CatchUp";//伸ばした時に腕を上げる処理のための文字列。これのフラグをtrueにして。
    public static readonly string AnimeExtendTrriger = "ExtendAction";//腕を伸ばすトリガー用文字列

    //パラメタ
    [SerializeField]
    private ArmParameter parameter;               //パラメーターデータオブジェクト
    private Dictionary<ARMstate, iArm> virtualARM;//各状態
    [SerializeField]                              //下記inspectorで設定。
    private ArmHIT hit;                           //アームの先のあたり判定。
    [SerializeField]                              //下記inspectorで設定CollisionClearオブジェクトセット
    private GameObject CliarObject;               //ブロックのあたり判定解除用。


    /// <summary>
    /// 初期化処理
    /// </summary>
    void Start()
    {
        //パラメタの初期化。
        parameter.anim       = GetComponent<Animator>();          //パラメーターにアニメーターを登録。
        parameter.gameObject = this.transform.gameObject;         //パラメーターに自分自身を登録。
        parameter.colllider  = GetComponent<BoxCollider>();       //パラメーターにコライダーを登録。
        parameter.creater    = this.CreateClear;                  //関数ポインタに登録。
        parameter.manager    = FindObjectOfType<GameController>();//ゲームコントローラーオブジェクトを登録スコアいじる用。
        parameter.sound      = GetComponent<AudioSource>();       //コンポーネント上から音源取得。

 
        hit.Initilize(this);                                      //アームHITの初期化を行う。

        //自分をプレイヤーに登録。
        iPartMonitor monitor = FindObjectOfType<PlayerContllor>();
        monitor.RegistrationArm(this);

        virtualARM = new Dictionary<ARMstate, iArm>();
        virtualARM[ARMstate.ON]  = new Arm_ON (ref parameter);
        virtualARM[ARMstate.OFF] = new Arm_OFF(ref parameter);
        virtualARM[ARMstate.UP]  = new Arm_UP (ref parameter);

        //初期はOFF
        parameter.status = ARMstate.OFF;

    }

    /// <summary>
    /// 各更新処理＋あたり判定（ArmHITのフラグがtrueであれば）。
    /// </summary>
    void Update()
    {
        virtualARM[parameter.status].Update();

        //あたり判定
        if (hit.isHIT)
        {
            var  col = hit.COLLIDER;
            virtualARM[parameter.status].Collision(ref col);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public int State()
    {
       return virtualARM[parameter.status].State();
    }

    /// <summary>
    /// UIのイベント処理
    /// </summary>
    public void OnArm()
    {
        //音を鳴らす。
        parameter.sound.PlayOneShot(parameter.sound.clip);
        virtualARM[parameter.status].Event();
    }

    /// <summary>
    /// ArmHITの参照用。
    /// </summary>
    public string Tag()
    {
       return virtualARM[parameter.status].tag();
    }

    /// <summary>
    /// コリジョンクリアオブジェクトを生成。
    /// 第一引数：生成ポジションを渡す。
    /// </summary>
    /// <param name="position"></param>
    public void CreateClear(Vector3 position)
    {
        Instantiate(CliarObject, position, Quaternion.identity);
    }

    /// <summary>
    /// イベント関数用。
    /// </summary>
    public void Event()
    {
        OnArm();
    }
}

/// <summary>
/// アームの状態用のインターフェース
/// </summary>
public interface iArm
{
    int     State();
    string  tag();
    void    Update();
    void    Event();
    void    Collision(ref Collider collision);
}


/// <summary>
/// アームが上がっている状態。【2】
///    (CatchUPアニメーション)
///    　　NonがTrueであればWaitになる。
/// </summary>
public class Arm_UP : iArm
{

    private ARM.ArmParameter parameter;

    public Arm_UP(ref ARM.ArmParameter param)
    {
        parameter = param;
    }

    /// <summary>
    /// 特にすることなし。
    /// </summary>
    /// <param name="collision"></param>
    public void Collision(ref Collider collision)
    {

    }

    /// <summary>
    /// UIが押された時の処理
    /// </summary>
    public void Event()
    {
        //状態をOFFに戻す。
        parameter.status = ARM.ARMstate.OFF;
        parameter.gameObject.tag = sTags.off;

        //コリジョンクリアオブジェクト生成
        parameter.creater(parameter.gameObject.transform.localPosition);

        //OFFに戻るフラグを立てる。
        parameter.anim.SetBool(ARM.AnimeWaitFlag, true);
    }

    /// <summary>
    /// プレイヤーに返す関数。
    /// </summary>
    /// <returns></returns>
    public int State()
    {
        return ARM.UP;
    }

    /// <summary>
    /// 予約
    /// </summary>
    public void Update()
    {
    }


    public string tag()
    {
        return sTags.on;
    }


}

/// <summary>
/// アームが伸びている状態。【1】{SetTrigger("Extend")で呼び出し}
///     (Extendアニメーション)
///       ExToUpがTrueであればCatchUpになる。
///       NonがTrueであればWaitになる。（優先）
/// </summary>
public class Arm_ON : iArm
{

    private ARM.ArmParameter parameter;

    public Arm_ON(ref ARM.ArmParameter param)
    {
        parameter = param;
    }

    /// <summary>
    /// tagで判定。
    /// Blockに当たった時の処理。
    /// Areに当たった時の処理。
    /// </summary>
    /// <param name="collision"></param>
    public void Collision(ref Collider collision)
    {
 
      if (collision == null) return;
    
      else if(collision.tag == sTags.Block)
        {
            //状態をUP状態にする。
            parameter.status = ARM.ARMstate.UP;
            //UPのアニメーションに必要なフラグを立てる。
            parameter.anim.SetBool(ARM.AnimeUpFlag, true);
        }
      
      else if(collision.tag == sTags.Are)
      {
            parameter.manager.score.AddPoint();//ポイント加算
            UnityEngine.Object.Destroy(collision.gameObject);
            GameObject.Instantiate(parameter.destroyEffect, collision.gameObject.transform.position, Quaternion.identity);
      }
    }


    /// <summary>
    /// UIで呼ばれた時の処理。
    /// </summary>
    public void Event()
    {
        //状態をOFFに戻す。
        parameter.status = ARM.ARMstate.OFF;
        //クリアオブジェクトを生成
        parameter.creater(parameter.gameObject.transform.position);
        //OFFに戻るフラグを立てる。
        parameter.anim.SetBool(ARM.AnimeWaitFlag, true);


    }


    /// <summary>
    /// プレイヤーに返す値。
    /// </summary>
    /// <returns></returns>
    public int State()
    {
        return ARM.ON;
    }

    /// <summary>
    /// 予約。
    /// </summary>
    public void Update()
    {

    

    }


    public string tag()
    {
        return sTags.on;
    }

}


/// <summary>
/// アームがウェイト状態【0】
///   (Waitアニメーション)
/// </summary>
public class Arm_OFF : iArm
{
    private  ARM.ArmParameter parameter;

    public Arm_OFF(ref ARM.ArmParameter param)
    {
        parameter = param;
    }

    /// <summary>
    /// 何もしない。
    /// </summary>
    /// <param name="collision"></param>
    public void Collision(ref Collider collision)
    {
       
    }

    /// <summary>
    /// UIのイベント処理
    ///    　アームのステータスの状態をONにする。
    /// </summary>
    public void Event()
    {

        //状態を更新
        parameter.status = ARM.ARMstate.ON;
        parameter.gameObject.tag = sTags.on;

        //各フラグを初期化。
        parameter.anim.SetBool(ARM.AnimeWaitFlag, false);
        parameter.anim.SetBool(ARM.AnimeUpFlag, false);

        parameter.manager.onArmEvent();

        //アームを伸ばすトリガー
        parameter.anim.SetTrigger(ARM.AnimeExtendTrriger);
    }

    /// <summary>
    /// プレイヤーに返す値。
    /// </summary>
    /// <returns></returns>
    public int State()
    {
        return ARM.OFF;
    }

    /// <summary>
    /// 予約
    /// </summary>
    public void Update()
    {
    }

    public string tag()
    {
        return sTags.off;
    }
}
﻿using UnityEngine;
using Global;


/// <summary>
/// Author:川上　遵
/// ソナーオブジェクト
/// 
/// Overview:
///     L鉱石が指定範囲内であればプレイヤーのメッセージに！を記載すし終わり（死ぬとき）に消す。
/// 
/// Param:
///     Lcol:コライダーの制御用に確保
///     Lplayer:プレイヤーが持っているTextMeshの制御するため
///     Lparticle:エフェクトの制御用
/// 
/// </summary>
public class Soner : MonoBehaviour
{

    SphereCollider col;
    PlayerContllor player;
    ParticleSystem particle;

   public  readonly static string ResultMessage = "!";

    /// <summary>
    /// Overview:
    ///     L各パラメーターの初期化
    /// </summary>
    void Start ()
    {
        player   = GameObject.FindObjectOfType<PlayerContllor>();//findなんで重いかも。見てる限り重くないかも　profileチェック。
        //各コンポーネントを取得
        col      = gameObject.GetComponent<SphereCollider>();
        particle = gameObject.GetComponent<ParticleSystem>();
	}
	
    /// <summary>
    /// Overview:
    ///     Lパーティクルが動いていなければ、プレイヤーのメッセージを初期化し、死ぬ。
    /// </summary>
	void Update ()
    {  
        col.radius += 0.03f;//あたり判定を大きくする。

        //パーティクルが再生中であれば戻る。
        if (particle.IsAlive()) return;


        player.message = PlayerContllor.NonMessage;//メッセージ初期化。

        Destroy(gameObject);//自分を殺す。
	}
    
    /// <summary>
    /// Overview:
    ///     Lあたり判定処理、鉱石を見つけ次第、プレイヤーのメッセージを更新する。
    /// </summary>
    /// <param name="collision"></param>
    void OnTriggerEnter(Collider collision)
    {
      
        if (collision.tag == sTags.Are || collision.tag == sTags.AreHidden)
        {
            player.message = ResultMessage;
        }
    }

}

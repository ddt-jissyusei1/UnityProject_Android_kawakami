﻿using UnityEngine;
using System.Collections;

/// <summary>
/// アームの先のあたり判定
/// </summary>
public class ArmHIT : MonoBehaviour
{
    [SerializeField]
    private iArmHITToARM Arm;  //ARMオブジェクト。
    [SerializeField]           //下記inspectorで設定。
    private bool hit;          //ブロックと当たったかどうかのフラグ
    private Collider collision;//当たったオブジェクトの情報。



    /// <summary>
    /// hitフラグの参照用。
    /// 当たっていたらtrue
    /// ゲッターのみ
    /// </summary>
    public bool isHIT
    {
        get
        {
            return hit;
        }
    }

    /// <summary>
    /// collision情報の参照用。
    /// ゲッターのみ
    /// </summary>
    public Collider COLLIDER
    {
        get
        {
            return collision;
        }
    }


    public void Initilize(iArmHITToARM arm)
    {
        collision = null;
        hit       = false;
        Arm       = arm;
    }

    /// <summary>
    /// hitフラグがtrueのままであれば
    /// falseに戻す。
    /// </summary>
    void FixedUpdate()
    {
        //タグの更新。
        gameObject.tag = Arm.Tag();

        if (!hit) return;

        hit = false;
        collision = null;
    }


    /// <summary>
    /// 当たったらオブジェクト情報格納するのみ。
    /// </summary>
    /// <param name="other"></param>
    void OnTriggerStay(Collider other)
    {
        hit = true;
        collision = other;

    }


}

﻿using UnityEngine;
using Global;
using UnityStandardAssets.CrossPlatformInput;
using System.Collections.Generic;
using System;
using System.Collections;



///プレイヤーのパラメータ全取得用窓口。
public interface playerObject
{
    sPlayer STATUS
    {
        get;
        set; 
    }
    
}

///プレイヤーの状態変異用窓口
public interface iPlaerState
{
    PLAYERSTATE STATE
    {
        get;
        set;
    }
}

///プレイヤーが操作する時用のインターフェース
public interface iEventController
{
    void Event();
}
public struct Parts
{
    public iParts arm;         //監視対象（アーム）
    public List<iParts> panels;//監視対象（ソーラーパネル）
}

/// <summary>
/// Author：川上　遵
/// 
///     着地したらゲームモード
///     プレイヤー操作オブジェクト
/// 
/// </summary>
[System.Serializable]
public struct sPlayer
{
    [SerializeField]
    public PLAYERSTATE state;               //プレイヤーの状態。
    public TextMesh textMesh;               //ソナーが鉱石にヒットしたとき用。
    public float speed;                     //プレイヤーの速度
    public float panel;                     //ソーラーパネルの1枚分のエネルギー
    public Parts parts;                     //各種パーツの状態数値
    public Rigidbody gravity;               //重力操作用
    public Vector3 localGravity;            //重力値
    public GameObject sand;                 //砂煙
}

[RequireComponent(typeof(TextMesh))]
[RequireComponent(typeof(Rigidbody))]
public class PlayerContllor : MonoBehaviour,iPartMonitor, playerObject,iPlaerState
{
   
    //プレイヤー管理下のオブジェクト参照使うかも？
    [SerializeField]
    private GameObject         sonerPre;    //ソナーのプレファブ
    [SerializeField]
    private sPlayer            status;      //プレイヤーのパラメタ
    [SerializeField]
    private AudioSource        sonerSound;  //ソーナーの音
    [SerializeField]
    public iEventController[] events;       //各イベント操作用inspectorビューで操作



    public static readonly int arm        = 0;
    public static readonly new int camera = 1;

    ///messageの初期化用。
    public static readonly string NonMessage = "";
    ///パネルの2分の１の計算用
    public static readonly float PanelHalf = 0.5f;
 
    /// <summary>
    /// 画面に表示するtextMeshの文字の更新用のセッター
    /// </summary>
    public string message
    {
        set { status.textMesh.text = value; }
    }


    /// <summary>
    /// StatePlayerに渡すステータス群
    /// </summary>
    public sPlayer STATUS
    {
        get
        {
            return status;
        }

        set
        {
            status = value;
        }
    }

    /// <summary>
    /// プレイヤーの状態
    /// </summary>
    PLAYERSTATE iPlaerState.STATE
    {
        get
        {
            return status.state;
        }

        set
        {
            status.state = value;
        }
    }


    /// <summary>
    /// Overview:
    ///     LStartイベントより前に行う処理
    ///     Lpanelsのリストを初期化
    /// </summary>
    void Awake()
    {
        status.parts.panels = new List<iParts>();
    }

    /// <summary>
    /// Overview:
    ///     L各パラメーターの初期化
    /// </summary>
    void Start ()
    {
       
        status.textMesh = GetComponent<TextMesh>();
        status.gravity  = GetComponent<Rigidbody>();
        status.state    = PLAYERSTATE.eStart;
        message         = NonMessage;
        status.speed    = 1.0f;
        status.panel    = status.speed * PanelHalf;

        //各種イベントの追加
        events         = new iEventController[2];
        events[arm]    = FindObjectOfType<ARM>();
        events[camera] = FindObjectOfType<GameView>();


        sonerSound = GetComponent<AudioSource>();

        status.gravity.useGravity = false;//全体の重力を受けない。
        status.localGravity = new Vector3(0.0f, -3.0f, 0.0f);//マイナス値が大きければ早く落ちる。

    }
	
    /// <summary>
    /// 物理演算系の更新処理
    /// </summary>
    void FixedUpdate()
    {
        status.gravity.AddForce(status.localGravity, ForceMode.Acceleration);
    }

    /// <summary>
    /// 更新処理
    /// </summary>
	void Update ()
    {
        if (status.state == PLAYERSTATE.ePLAY || status.state == PLAYERSTATE.eWAIT)
        {
            onUpdate_play();
        }else
        {
            onUpdate_wait();
        }
    }

    //ゲームプレイ中
    void onUpdate_play()
    {
        //一度状態を初期化
        status.state = PLAYERSTATE.eWAIT;


        var enelgy1 = status.parts.panels[0].State();
        var enelgy2 = status.parts.panels[1].State();

        var armState = status.parts.arm.State();

        //パネルが両方のエネルギーを計算
        var tempSpeed = (float)(status.panel * enelgy1 + status.panel * enelgy2) - (0.3f * armState);

        tempSpeed = Mathf.Clamp(tempSpeed, 0.0f, 1.0f);

        tempSpeed *= 0.5f;

        //誤差のため0.01以下にしています。
        if (tempSpeed <= 0.01f) return;
        status.state = PLAYERSTATE.ePLAY;

#if MOBILE_INPUT

#else
        //以後プレイヤーがプレイモードなので操作系は
        update_oparation();
#endif

        //現在の角度
        var localx = transform.localEulerAngles.y;
        //回転量　=　入力＊増加量 + 現在の角度
        var Verosity = Quaternion.AngleAxis(MyINPUT.Input.Horizontal() * tempSpeed * 2 + localx, Vector3.up);
        //回転
        transform.rotation = Verosity;
        //移動
        transform.Translate(0.0f, 0.0f, MyINPUT.Input.Vertical() * tempSpeed * 0.25f);
    }
    //アニメーション中
    void onUpdate_wait()
    {

    }
    

    /// <summary>
    /// プレイヤーの操作等・・
    /// </summary>
    void update_oparation()
    {
        ////////PC用////////////
        if (Input.GetKeyDown(KeyCode.LeftShift))
            //soner
            CreateSoner();
        if (Input.GetKeyDown(KeyCode.Space))
            //arm
            events[arm].Event();
        if (Input.GetKeyDown(KeyCode.Q))
            //camera
            events[camera].Event();
        ///////////////////////

    }

    /// <summary>
    /// Overview:
    ///     Lあたり判定、オブジェクトタグがクリアであれば自分の状態をクリアにする。
    /// </summary>
    /// <param name="collider"></param>
    void OnTriggerStay(Collider collider)
    {
        if(collider.tag == sTags.Clear)
        {
            status.state = PLAYERSTATE.eCLEAR;
        }
    }

    /// <summary>
    /// 当たった瞬間の処理
    /// </summary>
    /// <param name="collision"></param>
    void OnCollisionEnter(Collision collision)
    {
        if(collision.transform.tag == sTags.Filed)
        {
            Instantiate(status.sand, transform.position, Quaternion.AngleAxis(90, Vector3.right));
        }
    }


    /// <summary>
    /// Overview:
    ///     L入力イベント用
    ///     Lソナーオブジェクトを自分自身の位置に生成する。
    /// </summary>
    public void CreateSoner()
    {
        sonerSound.PlayOneShot(sonerSound.clip);
        Instantiate
            (sonerPre,
            transform.position,
            Quaternion.AngleAxis(90,Vector3.right));
           
    }

    //アームオブジェクト登録窓口
    void iPartMonitor.RegistrationArm(iParts _arm)
    {
        status.parts.arm = _arm;
    }
    //アームオブジェクト解除窓口
    void iPartMonitor.ErasureArm()
    {
        status.parts.arm = null;
    }
    //ソーラーパネル登録窓口
    void iPartMonitor.RegistrationEnergy( iParts other)
    {
        status.parts.panels.Add(other);
    }

}


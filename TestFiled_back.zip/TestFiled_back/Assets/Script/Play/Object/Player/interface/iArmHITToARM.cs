﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/// <summary>
/// アームの先のあたり判定（ArmHIT)と
/// アーム自体の窓口(ARM)
/// 
/// Blockのあたり判定に認識されるように
/// タグを変更する必要がある。（ArmHITの方）
/// 
/// ArmHITがONのタグの時にBlockが処理を行う流れになっている。
/// </summary>
/// 
public interface iArmHITToARM
{
    string Tag();
}


﻿

namespace MyINPUT
{
    /// <summary>
    /// 仮想ジョイスティックとキーボード処理
    /// </summary>
    class Input
    {

        private static float HORIZONTAL;   //左右
        private static float VERTICAL;     //前後


        public static bool IsKeyDown()
        {
            return UnityEngine.Input.anyKeyDown;
        }

        public static float Horizontal()
        {
                HORIZONTAL = UnityEngine.Input.GetAxis("Horizontal") + UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager.GetAxis("Horizontal");
            return UnityEngine.Mathf.Clamp(HORIZONTAL, -1,1);
        }

        public static float Vertical()
        {
        
            VERTICAL = UnityEngine.Input.GetAxis("Vertical") + UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager.GetAxis("Vertical");
            return UnityEngine.Mathf.Clamp(VERTICAL,-1,1);
        }

    }
}

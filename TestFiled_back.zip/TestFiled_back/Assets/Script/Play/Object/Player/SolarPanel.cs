﻿using UnityEngine;
using Global;
using System;

/// <summary>
/// Author：川上　遵
/// ソーラーパネルオブジェクト
/// 
/// targetにはinspectorビューで太陽のオブジェクトを渡す。
/// 
/// Param:
///     Ltarget:rayの飛ばす方向
///     LoffsetPosition:rayのスタート地点のずれ
///     LScale:四角の大きさ
///     LrayInfo:大きさ、方向、スタート地点、回転量
///     LEnable:Hitしたかどうか、プレイヤーに渡すため
///     
///     追記:
///        Lmonitor:自分を監視するオブジェクトが入ります。(プレイヤー）
/// </summary>
public class SolarPanel : MonoBehaviour, iParts
{

    //GUI操作用でpublic
    [SerializeField]
    private  Transform      target;         //Rayを飛ばす向き
    public  Vector3         offsetPosition; //Rayの原点をずらす
    public  float           Scale;          //BoxRayの大きさ
    private RayInfo<BoxRay> rayInfo;        //BoxRayの情報を格納
    private bool            enable;         //ヒットしたかどうかのフラグ
    private iPartMonitor    monitor;        //プレイヤーのインターフェース。


    /// <summary>
    /// Overview:初期化処理
    /// ・Rayの初期化
    /// ・ヒットしたかどうかのフラグの初期化
    /// ・監視してくれるオブジェクトを登録
    /// </summary>
    void Start()
    {
        rayInfo = new RayInfo<BoxRay>();
        enable = false;

        //監視してくれるオブジェクトを登録し自分を登録する。
        monitor = FindObjectOfType<PlayerContllor>();
        monitor.RegistrationEnergy(this);
    }

    /// <summary>
    /// Overview:Rayの処理。
    /// ・Rayの情報を更新
    /// ・Rayヒット処理
    /// </summary>
    void Update()
    {
        //RAY更新情報
        rayInfo.ray.scale       = target.transform.lossyScale.x * Scale * 0.5f;
        rayInfo.ray.center      = transform.position + offsetPosition;
        rayInfo.ray.direction   = target.position - rayInfo.ray.center;
        rayInfo.ray.rotation    = transform.rotation;

        //ヒットしたらtrue
        enable =
            Physics.BoxCast(
                rayInfo.ray.center,
                rayInfo.ray.scale * Vector3.one,
                rayInfo.ray.direction,
                out rayInfo.hit,
                rayInfo.ray.rotation);
                
    }

    /// <summary>
    /// Overview:
    ///     Lenableを反転して返す。
    ///         L太陽以外と当たったらtrueのため
    /// </summary>
    /// <returns>rayに太陽以外のオブジェクトがヒットしたらtrue</returns>
    int iParts.State()
    {
        return Convert.ToInt32(!enable);
    }

}

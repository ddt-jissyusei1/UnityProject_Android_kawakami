﻿using UnityEngine;
using System.Collections;
using Global;

/// <summary>
/// サンムーブ２
/// 　ライトを中心に回るようにする。
/// 　回るスピードだけをinspectorで選択。
/// </summary>
/// 
[System.Serializable]
public struct SUNPARAM
{
    public  Global.iGameTimeUpdate  gameTimer;      //ゲーム時間操作用 
    public  TimeInfo                framCountTimer; //何秒に一度処理する用。
    public  TimeInfo                waitTImer;      //プレイヤーが影にいる時間の計測用。
    public  iPlaerState             playerStatus;   //プレイヤーの状態操作用。
    [SerializeField][Range(0,999)]
    public float                    speed;          //回転速度。
}

public class SunMove2 : MonoBehaviour
{
    [SerializeField]
    private SUNPARAM param;
    [SerializeField]
    private float UpdateTime;//何秒に1回更新するのか
    [SerializeField]
    private float PlayerWaitTime;//プレイヤーが何秒間停止したら更新をするのか

	void Start ()
    {
        //1秒ごとに処理。
        param.framCountTimer = new TimeInfo(UpdateTime);
        //3秒間プレイヤーがWait状態だったら用。
        param.waitTImer      = new TimeInfo(PlayerWaitTime);
        //ゲーム時間更新用
        param.gameTimer      = FindObjectOfType<GameController>();
        //プレイヤー操作用
        param.playerStatus   = FindObjectOfType<PlayerContllor>();
	}
	
	void Update ()
    {
        param.framCountTimer.CurrentTime += Time.deltaTime;//時間計測。

        //プレイヤーが止まっていたら計測する。
        if (param.playerStatus.STATE == PLAYERSTATE.eWAIT) param.waitTImer.CurrentTime += Time.deltaTime;
        //止まっていなけれな計測初期化。
        else param.waitTImer.CurrentTime = 0.0f;


        //どちらかの時間がLimit時間以上であれば処理を行う。
        if (param.framCountTimer.IsOver() || param.waitTImer.IsOver())
            onUpdate();

	}

    /// <summary>
    /// プレイヤーが3秒以上Waitか1秒以上たったら
    /// 実効される。
    ///     ・回転処理。
    ///     ・時間の初期化。
    /// </summary>
    void onUpdate()
    {
        onTime();
        onRotation();
    }

    /// <summary>
    /// 回転処理.
    /// </summary>
    void onRotation()
    {
        transform.localRotation *= Quaternion.AngleAxis(Time.deltaTime * param.speed, Vector3.up);
    }

    /// <summary>
    /// フレームカウントの計測時間を初期化。
    /// ゲーム時間の処理。
    /// </summary>
    void onTime()
    {
        param.framCountTimer.CurrentTime = 0.0f;//フレームカウントの計測時間を初期化。
        param.gameTimer.TimeUpdate();//1秒経過
    }

}

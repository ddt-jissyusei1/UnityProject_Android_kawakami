﻿using UnityEngine;
using System.Collections;
using Global;

/// <summary>
/// ArmHITがONの時にJointを生成し
/// くっつく
/// ARMが生成するクリアオブジェクトにヒットしたら
/// 外れる（Jointのコンポーネント削除。)
/// </summary>
public class BlockMove2 : MonoBehaviour {

    private FixedJoint Join;           //joint操作用
    private bool hitFlag;              //あたり判定フラグ
    private bool createFlag;           //CreateJointの呼び出し回数制限用
    private Collider other;            //あたり判定避難所
    [SerializeField]
    private GameObject SandParticle;   //砂煙


    /// <summary>
    /// Overview:各種初期化
    /// </summary>
    void Start()
    {
        hitFlag = false;
        createFlag = false;
    }

    /// <summary>
    /// Overview:
    ///     autoFlag と createFlagが立っていなければ、jointの設定をする。
    /// </summary>
    void Update()
    {
        if (hitFlag && !createFlag) CreateJoint(ref other);
    }

    /// On時のアームとの処理
    void OnTriggerEnter(Collider collider)
    {
        var tag = collider.tag;
        if (tag == sTags.on)
        {
            hitFlag = true;
            other = collider;
        }
    }

    /// <summary>
    /// CollisionCliearとの処理。
    /// </summary>
    /// <param name="collider"></param>
    void OnTriggerStay(Collider collider)
    {
        var tag = collider.tag;

        if (tag == sTags.COLLISIONCLEAR)
        {
            hitFlag = false;
            createFlag = false;
            Destroy(Join);
        }


    }

    /// <summary>
    /// 床（FILED）に当たったら
    /// エフェクト(砂煙)を生成。
    /// 当たった瞬間に呼ばれる。
    /// </summary>
    /// <param name="collision"></param>
    void OnCollisionEnter(Collision collision)
    {
        var tag = collision.transform.tag;

        if (tag == sTags.Filed)
        {
            Instantiate(SandParticle, transform.position, Quaternion.AngleAxis(90, Vector3.right));
        }

        //見えない壁と当たったらJoint解除
        if (tag == sTags.WALL)
        {
            hitFlag = false;
            createFlag = false;
            Destroy(Join);
        }


    }

    /// <summary>
    /// Jointを生成し
    /// 引数で受け取ったオブジェクトにくっつく
    /// </summary>
    /// <param name="collider"></param>
    void CreateJoint(ref Collider collider)
    {
        Join = gameObject.AddComponent<FixedJoint>();
        Join.enableCollision = true;
        Join.connectedBody = collider.GetComponent<Rigidbody>();
        createFlag = true;
    }

}

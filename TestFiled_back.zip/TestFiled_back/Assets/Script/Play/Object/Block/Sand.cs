﻿using UnityEngine;
using System.Collections;

/// <summary>
/// 砂煙マン（ブロックの）
/// パーティクルを再生して終了したら死ぬ
/// </summary>
[RequireComponent(typeof(ParticleSystem))]
public class Sand : MonoBehaviour
{

    new ParticleSystem particleSystem;

    void Start ()
    {
        particleSystem = GetComponent<ParticleSystem>();
        particleSystem.loop = false;//ループオフ
        particleSystem.Play();
    }
	
	void Update ()
    {
        //再生が終了したら死ぬ。
        if (!particleSystem.IsAlive())
            Destroy(gameObject);
	}
}

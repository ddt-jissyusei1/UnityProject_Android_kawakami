﻿using UnityEngine;
using Global;
using UnityEngine.SceneManagement;
using System;

/// <summary>
/// 
/// Author:川上　遵
/// 
/// Overview:
///     Lプレイヤーが範囲内にいれば、ゲームクリアにする。
///     ゲームコントローラーが作成する。
///         
/// Param:
///     Lspherecollider:あたり判定制御用（いらないかも）
///     Lparticlesystem:エフェクト制御用
///     
///   　追記：
///   　 Lシーン切り替えを行う機能の追加。
///   　 LnextSceneName:次のシーンの名前を記載。
/// 
/// </summary>
[RequireComponent(typeof(SphereCollider))]
public class GameClear : MonoBehaviour
{
    [SerializeField]
    private string  nextSceneName;  //次のシーンの名前
    private bool GameEndSceneFlag;  //終わりのアニメーション待つ
    SphereCollider spherecollider;  //あたり判定制御用
    ParticleSystem particlesystem;  //エフェクト制御用。
    NextSceneEvent nextEvents;      //gameContorller
    Transform target;               //プレイヤーの座標吸寄せ用

    float endLimit;                 //シーンの呼び出し時間。
    float current;                  //シーンの呼び出しの経過時間


    public void Create( NextSceneEvent controller)
    {
        endLimit   = controller.EndLimit();
        nextEvents = controller;
    }

	void Start ()
    {
        particlesystem = GetComponent<ParticleSystem>();
        spherecollider = GetComponent<SphereCollider>();

        current = 0.0f;

        spherecollider.isTrigger = true;
        GameEndSceneFlag         = false;
        nextSceneName            = SceneName.Result;

	}
   
    /// <summary>
    /// ゲーム終了のイベントが
    /// 開始後処理を行う。
    /// </summary>
    void Update()
    {
       //ゲーム終了シーンに入ったら
        if (!GameEndSceneFlag) return;

        
        current += Time.deltaTime;
        if (current > endLimit)
            SceneManager.LoadScene(nextSceneName);
        
    }


    ///
	///プレイヤーと接触した際に処理が始まる。
	void OnTriggerEnter(Collider collision)
    {
        if (collision.tag == sTags.Player)
        {
            particlesystem.Stop();
            GameEndSceneFlag = true;
            nextEvents.Event();
        }
    }


}

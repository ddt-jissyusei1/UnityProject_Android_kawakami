﻿using UnityEngine;
using System.Collections;

/// <summary>
/// 検索用
/// </summary>
public class Spot : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
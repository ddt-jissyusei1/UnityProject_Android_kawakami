﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class RETRYButton : MonoBehaviour
{

    iGetSceneName gameController;
    Button button;

	void Start ()
    {
        //ゲームコントローラーを取得
        gameController = FindObjectOfType<GameController>();
        //ボタンを取得
        button         = GetComponent<Button>();
        //ボタンにイベントを登録。
        button.onClick.AddListener(() => { SceneManager.LoadScene(gameController.ToRetry()); });
    }

}

﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using Global;

/// <summary>
/// Filedの色を変える（ステージごとに）
/// マテリアルを取得し
/// カラーを変える。
/// </summary>
public class FiledColorStage : MonoBehaviour
{
   

    private readonly Color RED   = new Color(1f, 0.2f, 0f);  //Level_1
    private readonly Color GREEN = new Color(0.8f, 1f, 0.7f); //Level_2
    private readonly Color BROWN = new Color(0.85f, 0.65f, 0.65f );  //茶色
    private readonly Color PINK  = new Color(0.8f, 0.6f, 0.6f);//肌色

    private Dictionary<string, Color> materialColor;

    void Awake()
    {
        materialColor = new Dictionary<string, Color>();

        //純粋にifかswitcのほうが早いかも.

        materialColor[SceneName.Level1] = RED;
        materialColor[SceneName.Level2] = GREEN;
        materialColor[SceneName.Level3] = BROWN;
        materialColor[SceneName.Level4] = PINK;
    }

	void Start ()
    {
        
        GetComponent<Renderer>().material.SetColor
            (
            "_Color",
            materialColor[SceneManager.GetActiveScene().name]
            );

    }
	


}

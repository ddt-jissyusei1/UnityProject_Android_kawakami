﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Menu
{
    /// <summary>
    /// ポップアップUIの大元に登録されるオブジェクト。
    /// </summary>
    public interface PopText
    {
        void SetText(string text);
    }

    /// <summary>
    /// ポップアップUIの大元のオブジェクト。
    /// </summary>
    public interface PopWindow
    {
        void AddText(PopText ui);
    }

    /// <summary>
    /// Author:川上　遵
    /// 
    /// Overview:
    ///     ポップアップUIの各イベント処理
    /// </summary>
    public class PopUpUI : MonoBehaviour,iMenuSubject, PopWindow
    {

        iMenuObserbar manager;
        PopText       uiText;

        /// <summary>
        /// ゲームシーンの決定。
        /// </summary>
        public void onAgree()
        {
            manager.NextScene();
        }

        /// <summary>
        /// ゲームシーンの拒否
        /// </summary>
        public void onOpposition()
        {
            manager.DestroyPopUp();
            Destroy(gameObject);
        }

        /// <summary>
        /// 状態情報
        /// </summary>
        /// <returns>特に状態を持っていないため常に真</returns>
        public bool IsEnable()
        {
            return true;
        }

        /// <summary>
        /// テキストUIに表示する文字列を渡す関数。
        /// </summary>
        /// <param name="key">ウィンドウに表示する文字</param>
        public void MoveSet(string key)
        {
            if(uiText != null)
             uiText.SetText(key);
        }

        /// <summary>
        /// 自分を監視するオブジェクトを追加。
        /// </summary>
        /// <param name="other"></param>
        public void AddObserbar(iMenuObserbar other)
        {
            manager = other;
        }

        /// <summary>
        /// 自分が監視するオブジェクトを追加。
        /// </summary>
        /// <param name="ui"></param>
        public void AddText(PopText ui)
        {
            uiText = ui;
        }
    }


}

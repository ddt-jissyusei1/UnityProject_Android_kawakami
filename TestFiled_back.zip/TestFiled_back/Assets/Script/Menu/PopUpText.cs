﻿using UnityEngine;
using System;
using UnityEngine.UI;

namespace Menu
{

    /// <summary>
    /// Author: kawakami jun
    /// 
    /// Overview:
    ///     ポップアップに表示するテキストをステージごとに切り替える。
    ///     テキストはuiWindowからもらってくる。
    /// </summary>
    public class PopUpText : MonoBehaviour,PopText
    {
       
        Text uiText;
        PopWindow uiWindow;

        /// <summary>
        /// ポップアップUIから
        /// text属性のオブジェクトを持ってきて
        /// Textの中身を変化させる。
        /// </summary>
        void Awake()
        {
            uiWindow = GetComponentInParent<PopUpUI>();
            uiWindow.AddText(this);

            uiText = GetComponent<Text>();

        }

        public void SetText(string text)
        {
            uiText.text = text;
        }

    }

}
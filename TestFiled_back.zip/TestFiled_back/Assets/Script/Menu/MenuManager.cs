﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;


namespace Menu
{
    /// <summary>
    /// Author:川上　遵
    /// 
    /// Overview:
    ///     UIの処理が邪魔になってしまうと困る
    ///     オブジェクトが引き継ぐ。
    /// </summary>
    public interface iMenuSubject
    {
        bool IsEnable();
        void MoveSet(string key);
        void AddObserbar(iMenuObserbar other);
    }

    /// <summary>
    /// Author:川上　遵
    /// 
    /// Overview:
    ///     登録されているオブジェクトが処理している最中に
    ///     UIの処理をさせないためのインターフェース。
    ///     ついでに、ポップアップが死んでいるかどうかも。
    /// </summary>
    public interface iMenuObserbar
    {
        /// <summary>
        /// 次のシーンに移る際のイベント関数。
        /// </summary>
        void NextScene();

        /// <summary>
        /// 動いているときに
        /// プレイヤーの操作で
        /// 予想外の動きをしてしまわないように
        /// したいオブジェクトを登録。
        /// </summary>
        /// <param name="other"></param>
        void AddMoves(iMenuSubject other);

        /// <summary>
        /// UI全体を表示・非表示にするため
        /// 登録用。
        /// </summary>
        /// <param name="other"></param>
        void AddChangeActive(GameObject other);

        /// <summary>
        /// ポップアップUIが表示されているか
        /// </summary>
        /// <returns></returns>
        void DestroyPopUp();
    }

    /// <summary>
    /// ポップアップウィンドウの生成フラグ
    /// iPopUpWindowで使います。
    /// </summary>
    public interface iSimpleWindow
    {
        bool CreateFrag
        {
            set;
            get;
        }
    }

    /// <summary>
    /// Author:川上　遵
    /// 
    /// Overview:
    ///     メニューシーンの神!!
    /// 
    /// Pram:
    ///     LmoveObject:動いているかどうか確認をする用のオブジェクト。
    ///     LChangeActiveObject:表示、非表示を切り替える。
    ///     Llevel:次のシーンに移行する用の文字列が格納されてある
    ///     LPopup:ポップアップウィンドウの生成用
    ///     
    /// </summary>
    public class MenuManager : MonoBehaviour, iMenuObserbar, iSimpleWindow
    {
        private iMenuSubject        moveObjects;       //動いているかどうか確認する用
        private LevelBase           level;             //次のシーンい移行するようの文字列が格納されている。
        private GameObject          ChangeActiveObject;//表示、非表示を行うキャンバス。
        private Global.RayInfo<Ray> rayinfo;           //Ray情報
        public GameObject           Popup;             //ポップアップウィンドウの生成用
   
        [SerializeField]
        private GameObject          popup_massage;     //説明用ポップアップ
        private bool                popup_massage_frag;//説明用ポップアップのフラグ
        public  bool CreateFrag
        {
            set
            {
                popup_massage_frag = value;
            }

            get { return popup_massage_frag; }
        }

        [SerializeField]
        private float               distance;          //Rayの距離
        public bool                 createPopUp;       //Popupのフラグ（一度のみ処理用)
        public GameObject           createPointer;     //クリエイトする際の一時的なオブジェクト
        static readonly Vector3     popInstnceLocalSize = new Vector3(0.5f, 0.8f, 1);

 

        void Start()
        {
            rayinfo = new Global.RayInfo<Ray>();
            LevelBase.Instance(this);
            level = new Level_1();
            createPopUp = false;
            popup_massage_frag = false;
        }

        /// <summary>
        /// Rayを飛ばしヒットすれば、
        /// ポップアップウインドウ作成。
        /// </summary>
        void Update()
        {

            //動いていなければ
            if (!moveObjects.IsEnable())
            { ChangeActiveObject.SetActive(true); }

            if (!Input.GetMouseButton(0)) return;


            rayinfo.ray = Camera.main.ScreenPointToRay(Input.mousePosition);//ディスプレイのタッチ座標取得
            if (Physics.Raycast(rayinfo.ray, out rayinfo.hit, distance) && !createPopUp)
            {
                CreatePopUp();
            }

            //Debug.DrawRay(rayinfo.ray.origin, rayinfo.ray.direction * distance);
        }

        /// <summary>
        /// ポップアップウィンドウを生成。
        /// 
        /// キャンバスの親子関係にし、
        /// サイズを調節する。
        /// 
        /// </summary>
        public void CreatePopUp()
        {

            if (popup_massage_frag || createPopUp) return;
            createPopUp = true;


            createPointer = (GameObject)Instantiate(Popup, new Vector3(Screen.currentResolution.width / 2 ,Screen.currentResolution.height / 2), Quaternion.identity);
            createPointer.transform.parent = ChangeActiveObject.transform;
            createPointer.transform.localScale = popInstnceLocalSize;

            
            var panel = createPointer.GetComponent<PopUpUI>();
            panel.AddObserbar(this);
            panel.MoveSet(level.getTag());

            createPointer.transform.localPosition = Camera.main.transform.position;
        }

        /// <summary>
        /// シーン移行用の文字列の変更
        /// UI非表示
        /// カメラの動きも同時に更新させるようにする。
        /// 
        /// </summary>
        public void NextButton()
        {
            level = level.Next();
            ChangeActiveObject.SetActive(false);
            moveObjects.MoveSet(level.getTag());

            if (createPointer != null) { Destroy(createPointer); createPopUp = false; popup_massage_frag = false; }
         }

        /// <summary>
        /// シーン移行用の文字列の変更
        /// UI非表示
        /// カメラの動きも同時に更新させるようにする。
        /// </summary>
        public void BackButton()
        {
            level = level.Return();
            ChangeActiveObject.SetActive(false);
            moveObjects.MoveSet(level.getTag());

            if (createPointer != null) { Destroy(createPointer); createPopUp = false; popup_massage_frag = false; }
        }


        /// <summary>
        /// ポップアップウィンドウのイベント用。
        /// </summary>
        public void NextScene()
        {
            SceneManager.LoadScene(level.getTag());
        }


        /// <summary>
        /// 監視(動いているときの状態）するようのオブジェクトを登録
        /// 複数可。
        /// </summary>
        /// <param name="other"></param>
        public void AddMoves(iMenuSubject other)
        {
            moveObjects = other;
        }

        /// <summary>
        /// 監視（アクティブ状態）するようのオブジェクトを登録
        /// 1つのみ。
        /// </summary>
        /// <param name="other"></param>
        public void AddChangeActive(GameObject other)
        {
            ChangeActiveObject = other;
        }


        /// <summary>
        /// ポップアップウインドウUIが
        /// 死ぬ際に呼ぶ関数。
        /// </summary>
        public void DestroyPopUp()
        {
            createPopUp = false;
        }



        /// <summary>
        /// 説明文を生成。
        /// 
        /// キャンバスの親子関係にし、
        /// サイズを調節する。
        /// 
        /// </summary>
        public void CreateMessagePopUp()
        {
            //フラグが折れていたら
            if (popup_massage_frag || createPopUp ) return;

           

            popup_massage_frag = true;
            

            createPointer = (GameObject)Instantiate(popup_massage, new Vector3(Screen.currentResolution.width / 2, Screen.currentResolution.height / 2), Quaternion.identity);
            var window = createPointer.GetComponent<iPopUpWindow>();
            window.SetManager(this);

     
            //親オブジェクトのサイズの影響を受けない。
            createPointer.transform.SetParent(ChangeActiveObject.transform, false);
            //位置を再計算
            //createPointer.transform.localPosition -= ChangeActiveObject.transform.localPosition;
            createPointer.transform.localPosition =Camera.main.transform.position;
            createPointer.transform.localScale *= 3;
        }


    }

}
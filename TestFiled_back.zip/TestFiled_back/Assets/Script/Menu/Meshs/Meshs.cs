﻿using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Author:川上　遵
/// 
/// Overview:
///     正方形をsegmentValue値分の大きさ(0~1)したオブジェクト
/// 
/// Param:
///     Lmax:UV座標の一番左上の場合の一番大きな値。
/// 
/// </summary>
public class SegmentFrame
{
    private float  max;
    private float segment;//何等分に分割したか。
    public float Value
    {
        get { return max; }
    }
    /// <summary>
    /// Overview:
    ///     L何等分に整えるか。
    /// </summary>
    /// <param name="segmentValue">何等分</param>
    public SegmentFrame(float segmentValue)
    {
        max = 1 / segmentValue;
        segment = segmentValue;
    }

    /// <summary>
    /// Overview:
    ///     Framを所定位置までずらして渡す。
    ///     ずらさないのであれば、0を引数に渡す。
    /// </summary>
    /// <param name="offsetX">X座標をどのくらいずらすのか</param>
    /// <param name="offsetY">Y座標をどのくらいずらすのか</param>
    /// <returns>Framがずれた位置が返る。</returns>
    public Vector2[] ReSizeUV(int offsetX,int offsetY,Mesh objectmesh)
    {
        //UV座標と頂点の個数を取得
        var vertexCount = objectmesh.vertexCount;
        var UVs = objectmesh.uv;
        var UV = new Vector2[vertexCount];


        if (UVs.Length <= 0 || vertexCount <= 0)
        {
        }


        
        
        //元のUV座標をセグメントに加工する。
        for (var j = 0; j < vertexCount; j++)
        {


            //座標をセグメント分のサイズにする。
            var x = UVs[j].x * max;
            var y = UVs[j].y * max;

            var a = (max * offsetX);
            var b = (max * offsetY);
            Vector2 offset = new Vector2(a,b);

            x += offset.x;
            y += offset.y;

            UV[j] = new Vector2(x ,y);

        }

        return UV;

    }

}


/// <summary>
/// Author:川上　遵
/// 
/// Overview:
///     試作用
/// </summary>
public class Meshs : MonoBehaviour
{
   
    public Material          MainMaterial;  
    public int               segment;       //何等分かどうか
    private SegmentFrame     frame;         //最小の枠組み(最小のuv)

    private List<GameObject> chiledren;
    private List<Mesh>       polygons;      //メッシュに格納されているUVの操作用。
    private List<MeshRenderer> renders;     //マテリアルを統一するための操作用。

    [SerializeField]
    private Vector2[] offsets;//各オフセット値；

    void Start()
    {
        chiledren = new List<GameObject>();
        polygons = new List<Mesh>();
        renders = new List<MeshRenderer>();

        //chiledrenに挿入
        GetChiledrenAllW(this.gameObject);

        //各ゲームオブジェクトのMesh情報確保。
        GetMeshFileter();
        GetMeshRender();




        //最小フレームを作成。
        frame = new SegmentFrame(segment / 2);
  
        //座標変換
        for(int i = 0; i < polygons.Count; i++)
            polygons[i].uv = frame.ReSizeUV((int)offsets[i].x,(int)offsets[i].y ,polygons[i]);


        //マテリアル変更
        foreach (var i in renders)
        {
            i.material = MainMaterial;
        }

	}

    /// <summary>
    /// ・幅優先探索
    /// </summary>
    void GetChiledrenALLW()
    {
        GetChiledrenAllW(gameObject);
        for(int i = 0; i < chiledren.Count; i++)
        {
            if (chiledren[i].transform.childCount == 0) continue;
            GetChiledrenAllW(chiledren[i]);
        }
    }

    private void GetChiledrenAllW(GameObject other)
    {
        var trans = other.transform;
        
        for (int i = 0; i < trans.childCount; i++)
        {
            var tempObject = trans.GetChild(i).gameObject;
            chiledren.Add(tempObject);
        }

    }
    
    void GetMeshFileter()
    {
        polygons = new List<Mesh>();
        //メッシュ情報を格納。
        foreach(var chiled in chiledren)
        {
            polygons.Add(chiled.GetComponent<MeshFilter>().mesh);
        }

    }

    void GetMeshRender()
    {
        this.renders = new List<MeshRenderer>();
        //メッシュレンダラーを格納！！
        foreach(var chiled in chiledren)
        {
            this.renders.Add(chiled.GetComponent<MeshRenderer>());
        }
    }

    void UVsSettings(Mesh mesh,int indexNumber)
    {
        Vector2 uv = new Vector2();
        for (int i = 0; i < mesh.vertexCount; i++)
        {
           uv.x =  mesh.uv[i].x;
           uv.y =  mesh.uv[i].y;
        }
    }
    
}

﻿using UnityEngine;


namespace Menu
{
    /// <summary>
    /// Author:川上　遵
    /// 
    /// Overview:
    ///     カメラ移動時にユーザーがUIを操作しないように
    ///     制御を行う。（managerのクラスで非表示・表示を行っている）
    /// </summary>
    public class UI : MonoBehaviour
    {

        iMenuObserbar manager;


        void Start()
        {
            manager = FindObjectOfType<MenuManager>();
            manager.AddChangeActive(this.gameObject);
        }

    }
}
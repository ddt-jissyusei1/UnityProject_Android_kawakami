﻿using UnityEngine;
using System.Collections;

namespace Menu
{

    public class Level_2 : LevelBase
    {

        public Level_2()
        {
            tag = Global.SceneName.Level2;
        }

        public override LevelBase Next()
        {
            return menuInstance[2];
        }

        public override LevelBase Return()
        {
            return menuInstance[0];
        }
    }
}
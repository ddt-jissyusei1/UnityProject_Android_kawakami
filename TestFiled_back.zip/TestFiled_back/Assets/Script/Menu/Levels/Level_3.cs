﻿using UnityEngine;
using System.Collections;

namespace Menu
{
    public class Level_3 : LevelBase
    {

        public Level_3()
        {
            tag = Global.SceneName.Level3;
        }

        public override LevelBase Next()
        {
            return menuInstance[3];
        }

        public override LevelBase Return()
        {
            return menuInstance[1];
        }
    }


}
﻿using UnityEngine;
using System.Collections;

namespace Menu
{
    /// <summary>
    /// 識別用で作成し、次の処理と戻る用に必要な処理を行う。
    /// 各Levelは同じような仕様。
    /// </summary>
    public class Level_1 : LevelBase
    {

        public Level_1()
        {
            tag = Global.SceneName.Level1;

        }

        public override LevelBase Next()
        {
            return menuInstance[1];
        }

        public override LevelBase Return()
        {
            return menuInstance[0];
        }
    }
}
﻿using UnityEngine;
using System.Collections.Generic;
using System;

namespace Menu
{

    /// <summary>
    /// Author:川上　遵
    /// 
    /// Overview:カメラの操作
    ///     1秒で指定（targetPosition）に行く。
    ///     外部でこのプログラムを有効(Enable = true)をしなければ
    ///     動かないようにしてある。
    /// </summary>
    public class CameraMove : MonoBehaviour, iMenuSubject
    {

        public Vector3 targetPosition;             //カメラが行く位置
        private Vector3 startPosition;             //過去（動く前）の位置

        public float speed;                        //速度
        bool moveFlag;                             //動いているかどうか
        Global.TimeInfo timeinfo;                   //どのくらい動くかの時間計測用
        Dictionary<string,Vector3> NextPosition;    //各カメラ位置を保持



        void Start()
        {
            //マネージャーオブジェクトが空の場合探す。
            //マネージャーに監視してもらうように登録する。
            FindObjectOfType<MenuManager>().AddMoves(this);

            timeinfo = new Global.TimeInfo(2.0f, 0.0f);
            moveFlag = false;

            //移動位置を設定する。
            NextPosition = new Dictionary<string, Vector3>();
            NextPosition[Global.SceneName.Level1] = new Vector3(-2, 3.4f, 0.3f);
            NextPosition[Global.SceneName.Level2] = new Vector3(4.3f, 6, 6f);
            NextPosition[Global.SceneName.Level3] = new Vector3(-5.6f, 7, 11);
            NextPosition[Global.SceneName.Level4] = new Vector3(-0.76f, 8.15f, 17);
        }

        void Update()
        {
            if (!moveFlag) return;
            var diff = Time.timeSinceLevelLoad - timeinfo.CurrentTime;

            //指定時間になったら移動をやめる
            if (diff >= timeinfo.TimeLimit) moveFlag = false;

            var rate = diff / timeinfo.TimeLimit;

            transform.position = Vector3.Lerp(startPosition, targetPosition, diff);
        }


        /// <summary>
        /// オブジェクトが有効状態化
        /// </summary>
        /// <returns>オブジェクト自体の有効フラグ..trueの場合OnEnable()が呼ばれる。</returns>
        public bool IsEnable()
        {
            return moveFlag;
        }

        /// <summary>
        /// イベント処理用。
        /// </summary>
        /// <param name="key"></param>
        public void MoveSet(string key)
        {
            OnUpdate(key);
        }

        /// <summary>
        /// 行動する際に必要なものを設定するメソッド。
        /// </summary>
        /// <param name="target"></param>
        public void OnUpdate(string hashkey)
        {
            moveFlag = true;

            //スタートタイムをセット
            timeinfo.CurrentTime = Time.timeSinceLevelLoad;

            //現在位置を登録する。
            startPosition = transform.position;

            //目標位置を登録
            targetPosition = NextPosition[hashkey];

        }

        public void AddObserbar(iMenuObserbar other)
        {
         
        }
    }

}
﻿using UnityEngine;

using System.Collections.Generic;

namespace Menu
{
/// <summary>
/// Author:川上遵
/// 
/// Overview:
///     ステージ選択の際に、次のシーンへの
///     文字列を返す用。
/// </summary>
    public abstract class LevelBase : MonoBehaviour
    {

        protected static iMenuObserbar obserbar;
        protected static List<LevelBase> menuInstance;
        protected new string tag;


        /// <summary>
        /// 初期化時は絶対に呼び出してください。
        /// </summary>
        /// <param name="obser"></param>
        public static void Instance(iMenuObserbar obser)
        {
            if (obserbar != null) return;
            obserbar = obser;
            menuInstance = new List<LevelBase>();
            menuInstance.Add(new Level_1());
            menuInstance.Add(new Level_2());
            menuInstance.Add(new Level_3());
            menuInstance.Add(new Level_4());
        }

        /// <summary>
        /// tag文字列（次のシーンを呼び出すための文字列を格納）の参照用
        /// </summary>
        /// <returns>tag</returns>
        public string getTag()
        {
            return tag;
        }

        /// <summary>
        /// 進むボタンをおした際の処理
        /// </summary>
        public abstract LevelBase Next();

        /// <summary>
        /// 戻るボタンをおした際の処理
        /// </summary>
        public abstract LevelBase Return();
    }
}
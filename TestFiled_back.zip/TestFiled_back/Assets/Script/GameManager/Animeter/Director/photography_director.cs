﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

//撮影監督
abstract class photography_director
{
    static protected Performer_list list;   //出演者リスト
    static protected iViewAndUIToGame game; //UIとViewの操作
    static protected Transform[] targetList;//カメラの注視リスト
    protected bool update_end;            //更新処理終了フラグ
    protected int temp_type;              //updateのリターンで返す用の変数

    /// <summary>
    /// 出演者の登録
    /// </summary>
    /// <param name="onlist"></param>
    public static void RegistList(ref AnimetarController.parameter onlist)
    {
        list = onlist.pList;
        game = onlist.game;
        targetList = onlist.targetList;
    }


    public photography_director()
    {
        temp_type = ANIMETAR_CONTEXT.zero;
    }

    /// <summary>
    /// テンプレートメソッド
    /// </summary>
    /// <returns></returns>
    public int UPDATE()
    {
        
        update();

        if (update_end)
            finalize();

        return temp_type;
    }

    /// <summary>
    /// 初期化処理
    /// </summary>
    public abstract void initilize();

    /// <summary>
    /// 更新処理
    /// </summary>
    protected abstract void update();


    /// <summary>
    /// 終了処理
    /// </summary>
    protected abstract void finalize();
}
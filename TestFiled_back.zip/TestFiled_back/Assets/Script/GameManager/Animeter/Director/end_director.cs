﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/// <summary>
/// 終了シーンの監督
/// </summary>
class end_director : photography_director
{
    /// <summary>
    /// 初期化処理　呼び出さないと意味ない
    /// </summary>
    public override void initilize()
    {
        update_end = false;
        temp_type = ANIMETAR_CONTEXT.two;
    }

    /// <summary>
    /// 終了処理 一度だけ呼ばれる.
    /// </summary>
    protected override void finalize()
    {

    }
    /// <summary>
    /// 更新処理
    /// </summary>
    protected override void update()
    {
        
    }
}
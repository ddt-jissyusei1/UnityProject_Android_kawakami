﻿using UnityEngine;

/// <summary>
/// スタートシーンの監督...0
/// </summary>
class start_director : photography_director
{
    int count;//時間計測用比較対象はMAX_COUNT
    const int MAX_COUNT = 60 * 5 + 10;//待ち時間
    //const int MAX_COUNT = 650;//ドリー用の待ち時間
    //readonly Vector3 DORRYDISTANCE = new Vector3(-1.1f, 0.3f, 0.7f);//ドリー時の移動先
    readonly Vector3 DISTANCE_OFFSET = new Vector3(0.3f, 0.1f, 2.3f);//CAMERAの移動先
    readonly float AnimeTimer = 6.0f;//アニメーション用の計測

    Global.AutoBool animeFrag;//アニメーション用のフラグ

    //float DorryTime; //ドリーする時間
    //float DorrySpeed;//ドリーのスピード

    /// <summary>
    /// 初期化処理　呼び出さないと意味ない
    /// </summary>
    public override void initilize()
    {
        update_end = false;
        temp_type = ANIMETAR_CONTEXT.zero;
        //DorryTime = 0.142f;
        //DorrySpeed = 0.1f;
        animeFrag.Initilize(AnimeTimer);
    }

    /// <summary>
    /// 終了処理 一度だけ呼ばれる.
    /// </summary>
    protected override void finalize()
    {
        game.UIActive(true);
        game.CameraChangeTPS();
        temp_type = ANIMETAR_CONTEXT.one;
        list.pState.STATE = Global.PLAYERSTATE.ePLAY;
    }

    /// <summary>
    /// 更新処理
    /// </summary>
    protected override void update()
    {
        if (animeFrag.FLAG && list.mState.IsAction() == MatherShipMove.ActionMode.Play)
        {   
           //list.cState.Dorry(DorryTime, DorrySpeed, DORRYDISTANCE, targetList[0]);
           list.cState.Move(targetList[0].position, DISTANCE_OFFSET);
           animeFrag.onUpdate();
        }
            
        //プレイヤーの状態がアニメーション以外であれば
        if (list.mState.IsAction() == MatherShipMove.ActionMode.Play)
            count++;
        if (count > MAX_COUNT) update_end = true;
    }
}
﻿

/// <summary>
/// プレイシーンの監督
/// </summary>
class play_director : photography_director
{

    /// <summary>
    /// 初期化処理　呼び出さないと意味ない
    /// </summary>
    public override void initilize()
    {
        update_end = false;
        temp_type = ANIMETAR_CONTEXT.one;
    }

    /// <summary>
    /// 終了処理 一度だけ呼ばれる.
    /// </summary>
    protected override void finalize()
    {
        game.UIActive(false);
        game.CameraChangeMOVIE();
        temp_type = ANIMETAR_CONTEXT.two;//次の状態にするようにする。

    }
    /// <summary>
    /// 更新処理
    /// </summary>
    protected override void update()
    {
        if (list.pState.STATE == Global.PLAYERSTATE.eCLEAR)
            update_end = true;
    }
}
﻿using System;
using UnityEngine;
using System.Collections.Generic;



//各ディレクターが返す値
class ANIMETAR_CONTEXT
{
    public static readonly int zero = 0;
    public static readonly int one = 1;
    public static readonly int two = 2;
}

//出演者リスト
struct Performer_list
{
   public iPlaerState pState;         //プレイヤーの状態 get,set
   public CameraController cState;    //カメラの状態 get,set
   public MatherStatus mState;        //マザーシップの状態 ジョイントとアクションの確認のみ
}


/// <summary>
/// 総合監督
/// </summary>
/// 
class AnimetarController:MonoBehaviour
{

    public struct parameter
    {
        public Performer_list pList; //出演者
        public iViewAndUIToGame game;//ゲームのUIとViewの変更設定用オブジェクト
        public Transform[] targetList;//カメラのターゲット
    }
    [SerializeField]
    parameter param;

    /// <summary>
    /// 各ディレクターが
    /// カメラとUIの表示をコントロールする
    /// できればシーンのタイミングもやらせたい・・・非常に大変でした
    /// </summary>
    photography_director[] Directors;
    [SerializeField]
    int scene;//シーン


    void Start()
    {
        param.game = FindObjectOfType<GameController>();
        param.targetList = new Transform[TARGET_LIST_SIZE];
        Directors = new photography_director[DIRECTOR_MAX_NUM];
        Initilize();

        ///ターゲットの初期化
        param.targetList[0] = FindObjectOfType<PlayerContllor>().transform;



        ///ディレクターの初期化
        photography_director.RegistList(ref param);
        Directors[0] = new start_director();
        Directors[1] = new play_director();
        Directors[2] = new end_director();

        Directors[0].initilize();
        Directors[1].initilize();
        Directors[2].initilize();

        scene = 0;
    }
    
    void FixedUpdate()
    {
       scene = Directors[scene].UPDATE();
    }


    ///各出演者の初期化
    public void Initilize()
    {
       param.pList.pState = FindObjectOfType<PlayerContllor>();
       param.pList.cState = FindObjectOfType<GameView>();
       param.pList.mState = FindObjectOfType<MatherShipMove>();
    }

    ///////////////////////////下記定数///////////////////////////////
    static public readonly int DIRECTOR_MAX_NUM = 3;//ディレクターの人数
    static public readonly int TARGET_LIST_SIZE = 1;//ターゲットリストのサイズ

}







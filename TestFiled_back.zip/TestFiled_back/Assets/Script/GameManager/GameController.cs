﻿using UnityEngine;
using Global;
using UnityEngine.SceneManagement;
using UnityStandardAssets.CrossPlatformInput;
using System.Collections.Generic;

/// <summary>
/// Author:川上　遵
/// ゲームコントロールオブジェクト
///     ゲームクリアオブジェクトに時間を渡して次のシーンへ移る
///     カメラの操作もここ
///     マザーシップの状態で処理が変更される。
///     limitTimeSecond:ゲーム自体の制限時間（秒）※実時間ではない。
///     Actives:アクティブ・非アクティブの操作。
///         
/// 　　マザーシップ依存の書き方をしてしまった・・・・
/// 
/// </summary>
public class GameController : 
    SingletonMono<GameController> ,
    iGameTimeUpdate,
    iViewAndUIToGame,
    iGetSceneName,
    NextSceneEvent,
    iCameraToArm
{
    [SerializeField]
    private GameObject          ClearArea;        //クリアオブジェクトを生成するための設計図的な奴。
    [SerializeField]
    private Transform           instancePosition; //クリアオブジェクトの生成するポジション
    private bool                firstFlag;        //一度だけの処理用のフラグ。
    private string              playSceneName;    //プレイ中のシーンに変えるために保存.

    [SerializeField]
    private int                 limitScore;       //限界スコア インスペクタービューで変更     
    public  Score               score;            //現在のスコア管理
    [SerializeField]
    private  float              limitTimeSecond;  //制限時間. インスペクタービューで変更         
    private CountTime           timer;            //時間計測用。


    //マザーシップのアニメーションのため。
    //各アクティブ操作用。
    public  ActiveLIST              actives;            //アクティブ、非アクティブの状態を切り替えるようのオブジェクト。
    private CameraController        view;               //カメラの操作を切り返すためのオブジェクト
    private iMatherEventController  matherStatus;       //マザーシップの現在のステータスを取得。
    private iPlaerState             playerStatus;       //プレイヤーの状態

    private readonly float          NextResultSceneTime //次のシーンへどのくらいの時間で遷移するか
        = Global.MatherShipAnimationTimes.EndActionTime;//母艦が星から離れるシーンの総合時間

    delegate void methode();                                                 //void型の関数ポインタ宣言。
    private Dictionary<MatherShipMove.ActionMode, methode> virtualTimeUpdate;//各TimeUpdate処理。



    /// <summary>
    /// Overview:
    /// ・Start関数の前およびインスタンス化直後に呼び出されます
    /// ・もしオブジェクトがスタート時に無効の時、有効になるまでこの関数は呼び出されません。
    /// ・追記・ゲームオブジェクト、コンポーネントの処理はこちらでは書いてはいけない。
    /// </summary>
    void Awake()
    {
 
        if (Instance != this)
        {
            Destroy(this);
            return;
        }
        else
            //新しいシーンを読み込んでもオブジェクトが自動で破棄されないように設定。
            DontDestroyOnLoad(gameObject);


        score   = new Score();
        timer   = new CountTime();
        actives = new ActiveLIST();

        
        virtualTimeUpdate = new Dictionary<MatherShipMove.ActionMode, methode>();
        virtualTimeUpdate[MatherShipMove.ActionMode.Start]  = () => { };
        virtualTimeUpdate[MatherShipMove.ActionMode.Play]   = () =>
        {
            timer.NextSecond();
        };
        virtualTimeUpdate[MatherShipMove.ActionMode.End]    = () => { };

    }


    void Start ()
    {
        Initilize();
    }

    /// <summary>
    /// Overview:
    ///     ・各パラメータの初期化
    ///     ・UIの非表示。
    ///     ・リフレッシュオブジェクトに呼ばれる。
    ///     　　Unityの仕様で呼ばれなかったため
    /// </summary>
    public void Initilize()
    {
        //タッチ有効化
        CrossPlatformInputManager.SwitchActiveInputMethod(CrossPlatformInputManager.ActiveInputMethod.Touch);

        playerStatus     = FindObjectOfType<PlayerContllor>();
        matherStatus     = FindObjectOfType<MatherShipMove>();
        view             = FindObjectOfType<GameView>();

        instancePosition = FindObjectOfType<Spot>().transform;

        //シーン名の保存
        playSceneName = SceneManager.GetActiveScene().name;

        timer.Initilize();
        score.Initilize();

        firstFlag = true;
        actives.SET(false);
    }

    /// <summary>
    /// Overview:
    ///     ・limitScoreに達成したらゴールエリア（クリアエリア）を生成
    /// </summary>
	void Update ()
    {
        
        if (matherStatus == null) return;


        //クリア目標を達成したらクリアエリアを生成。
        if (score.value >= limitScore && firstFlag)
        {
            //プレハブをインスタンス化
            var instance = (GameObject)Instantiate
                   (
                        ClearArea,
                        instancePosition.position,
                        instancePosition.rotation * Quaternion.AngleAxis(90, Vector3.right)
                   );

            //スクリプトを取得。
            var script = instance.GetComponent<GameClear>();
            script.Create(this);//自分を渡す

            firstFlag = false;
        }

        //ゲームオーバー処理。
        //LimitTimeをオーバーしたら初期化しておく念のため。
        if (timer.TIME.seccond >= limitTimeSecond)
        {
            timer.Initilize();
            score.Initilize();
            SceneManager.LoadScene(SceneName.gameOver);
        }

    }



    /// <summary>
    /// Sunが実行・操作する関数。
    /// 実効すると1秒経過
    /// </summary>
    void iGameTimeUpdate.TimeUpdate()
    {
        if (matherStatus == null) return;
         virtualTimeUpdate[matherStatus.IsAction()]();
    }
    
    /// <summary>
    /// Overview:
    ///     ・スコア参照用のゲッター
    /// </summary>
    /// <returns>int型2つ返る。first:現在の個数。second:目標個数。</returns>
    public Pair<int> GetScore()
    {
        Pair<int> result;
        result.first = score.value;
        result.second = limitScore;

        return result;
    }

    /// <summary>
    /// ゲームのタイムを返す。
    ///     1番目は経過時間。
    ///     2番目は制限時間。
    /// </summary>
    public Pair<TIME, float> GetTimers()
    {
        var pair = new Pair<TIME, float>();
        pair.first = timer.TIME;
        pair.second = limitTimeSecond;

        return pair;
    }

    /// <summary>
    /// UIを表示、非表示を切り替える。
    /// </summary>
    /// <param name="other"></param>
    public void UIActive(bool other)
    {
        actives.SET(other);
    }

    /// <summary>
    /// viewの状態を切り返る。
    /// </summary>
    public void CameraChangeTPS()
    {
        view.Index = GameView.TPS;
    }

    /// <summary>
    /// viewの状態を登場、クリアシーン用
    /// </summary>
    public void CameraChangeMOVIE()
    {
        view.Index = GameView.Mather;
    }

    /// <summary>
    /// ゲームオーバー用
    /// 　戻り値はタイトルシーンへ移行するための文字列。
    /// </summary>
    public string ToTitle()
    {
        return Global.SceneName.Title;
    }

    /// <summary>
    /// ゲームオーバー用
    /// 　戻り値は現在のゲームシーンへ移行するための文字列。
    /// </summary>
    public string ToRetry()
    {
        return playSceneName;
    }

    /// <summary>
    /// エンドシーンの終了時間。
    /// </summary>
    /// <returns></returns>
    public float EndLimit()
    {
        return NextResultSceneTime;
    }

    /// <summary>
    /// ゲームクリアオブジェクトとプレイヤーが当たったら
    /// </summary>
    public void Event()
    {
        matherStatus.Event();
        matherStatus = null;
        playerStatus = null;
    }

    /// <summary>
    /// アーム伸ばした際の
    /// カメライベント
    /// </summary>
    public void onArmEvent()
    {
        view.ArmEvnet();
    }
}



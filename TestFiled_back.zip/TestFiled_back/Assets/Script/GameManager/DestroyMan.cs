﻿using UnityEngine;
using System.Collections;

/// <summary>
/// デストロイマン
/// 　　ゲームコントローラを絶対に何が何でもデストロイする。
/// 　　配置したら
/// 　　　　探し出し
/// 　　　　シーン終わりにデストロイ！！！
/// </summary>
public class DestroyMan : MonoBehaviour {

    [SerializeField]
    GameController DestroyTarget;

    //見つけ出す。
	void Start ()
    {
        DestroyTarget = FindObjectOfType<GameController>();
	}
	

    //死に際にデストロイ
    void OnDestroy()
    {
        Destroy(DestroyTarget.transform.gameObject);
    }

}

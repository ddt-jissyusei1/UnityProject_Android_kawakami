﻿using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Overview:
///     アクティブオブジェクトの管理。
/// </summary>
public class ActiveLIST
{
    List<iActive> activeList;
    
    /// <summary>
    /// リストのヒープ確保
    /// </summary>
    public ActiveLIST()
    {
        activeList = new List<iActive>();
    }
    public void Add(iActive other)
    {
        activeList.Add(other);
    }
    public void SET(bool other)
    {
        foreach (var obj in activeList)
            obj.ACTIVE = other;
    }
    public void Remove()
    {
        foreach(var i in activeList)
        {
            activeList.Remove(i);
        }
    }
    public bool IsNULL()
    {
        return activeList.Count == 0;
    }

}
﻿using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// デバッグ用のゲームオーバーゾーン
/// 一様プロジェクトに配置している。
/// </summary>
public class GameOver : MonoBehaviour
{
    iUIobserver gameinfo;
    bool firstFlag;//一回のみ処理用。

    void Start()
    {
        gameinfo = FindObjectOfType<GameController>();
        firstFlag = true;
    }

 

    void OnTriggerEnter(Collider other)
    {
        if(other.tag == Global.sTags.Player)
        {
            SceneManager.LoadScene(Global.SceneName.gameOver);
        }
    }
}

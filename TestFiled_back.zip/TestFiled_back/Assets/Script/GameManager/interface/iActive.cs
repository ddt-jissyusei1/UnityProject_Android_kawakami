﻿using System;
using UnityEngine;

/// <summary>
/// Overview:
///     アクティブ状態操作および確認。
/// </summary>
 public interface iActive
{ 
    bool ACTIVE
    {
        set;
        get;
    }
}
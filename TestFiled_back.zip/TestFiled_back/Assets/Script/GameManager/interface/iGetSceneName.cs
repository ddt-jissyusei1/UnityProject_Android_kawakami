﻿
/// <summary>
/// GameOverシーンの際に
/// リトライ時の前のシーンネームの取得。
/// 
/// </summary>
interface iGetSceneName
{
    /// <summary>
    /// タイトルシーンの名前を取得する。
    /// 　使っていない。
    /// </summary>
    /// <returns></returns>
    string ToTitle();
    /// <summary>
    /// 前のシーンの名前を取得する。
    ///  使用中。
    /// </summary>
    /// <returns></returns>
    string ToRetry();
}


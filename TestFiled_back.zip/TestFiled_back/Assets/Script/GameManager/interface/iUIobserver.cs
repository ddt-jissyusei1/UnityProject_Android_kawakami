﻿using Global;

/// <summary>
/// Overview:
///     UI系のオブジェクトに対して必要な情報の参照用。
/// </summary>
public interface iUIobserver
{
    /// <summary>
    /// Overview:
    ///     ・スコア参照用のゲッター
    /// </summary>
    /// <returns>int型2つ返る。first:現在の個数。second:目標個数。</returns>
    Pair<int> GetScore();

    /// <summary>
    /// ゲームのタイムを返す。
    ///     1番目は経過時間。
    ///     2番目は制限時間。
    /// </summary>
    Pair<TIME, float> GetTimers();
}

/// <summary>
/// GameClearオブジェクトに対して受託する処理用窓口。
/// </summary>
public interface NextSceneEvent:iUIobserver
{
    //マザーシップのイベント処理を取得。
    //UIの表示、非表示を行う。
    float EndLimit();
    void Event();
}
﻿using System;

/// <summary>
/// Overview:
///     マザーシップとGameControllerの窓口。
///     GameControllerが継承。
/// </summary>
public interface iViewAndUIToGame
{
    /// <summary>
    /// 表示状態の操作。
    /// </summary>
    /// <param name="other">true:表示,false:非表示.</param>
    void UIActive(bool other);
    /// <summary>
    /// カメラをTPS視点に変更
    /// </summary>
    void CameraChangeTPS();
    /// <summary>
    /// カメラをムービー用に変更
    /// </summary>
    void CameraChangeMOVIE();
}


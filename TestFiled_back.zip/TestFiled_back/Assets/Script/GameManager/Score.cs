﻿/// <summary>
/// Author:川上　遵
/// ※作りたくなかったけど作った。きれいに見えるため。
/// 
/// Overview:スコアの記録。および加算
/// 
/// Param:
///     Lcurrent:現在のポイントの保持
/// 
/// Method:
///     Lvalue:パラメータのゲッタ
///     LInitilize:ポイントの初期化
///     LAddPoint:ポイントの加算、引数分加算を行う
///     LDemPOint:ポイントの減算、引数分減算を行う
/// </summary>
public class Score
{
    private int current;
    public int value
    {
        get
        {
            return current;
        }
    }

	public void Initilize ()
    {
        current  = 0;
	}
    //加算
    public void AddPoint()
    {
        current++;
    }
    public void AddPoint(int value)
    {
        current += value;
    }
    //減点
    public void DemPoint()
    {
        current--;
    }
    public void DemPoint(int value)
    {
        current -= value;
    }

}

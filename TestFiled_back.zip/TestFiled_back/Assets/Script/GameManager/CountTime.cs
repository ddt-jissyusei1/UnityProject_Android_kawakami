﻿using UnityEngine;
using Global;
/// <summary>
/// Author:川上　遵
/// Overview:時間、分、秒を計測します。
/// 
/// Param:
///     Ln:約１/60の数値をマイフレーム加算して保持しておく変数。
///     Ltime:時間、分、秒を格納する変数。
/// 
/// Method:
///     LTIME:パラメタのゲッター
///     LInitilize:パラメタ初期化
///     LUpdate:時間の計測（UnityEngine依存）
///     LSecond:秒で返す。
///     LNextSecond:1秒進める
///     LNextMinute:1分進める
///     LNextHour:1時分進める
/// </summary>
public class CountTime
{

    float n;
    TIME time;

    public TIME TIME
    {
        get
        {
            return time;
        }
    }

    public void Initilize ()
    {
        n = 0.0f;
        time.s = 0;
        time.m = 0;
        time.h = 0;
	}
	
	public void Update ()
    {
        //Time.timeSinceLevelLoadでもよい。こっちのほうが正確。
        n += Time.deltaTime;

        time.s = (int)n % 60;
        time.m = (int)(n / 60);
        time.h = (int)(time.m / 60);

        if (time.s >= 60) n = 0;
	}

    public void NextSecond()
    {
        time.s += 1;
    }
    public void NextMinute()
    {
        time.m++;
    }
    public void NextHour()
    {
        time.h++;
    }
}

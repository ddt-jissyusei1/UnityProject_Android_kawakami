﻿using UnityEngine;
using System.Collections;
using System;

public  interface iCreateFrag
{
    bool IsCrete
    {
        set;get;
    }
}

public class testPopUp : MonoBehaviour,iCreateFrag
{
    [SerializeField]
    private GameObject window;
    private bool CreateFlag;

    public bool IsCrete
    {
        get
        {
            return CreateFlag;
        }

        set
        {
            CreateFlag = value;
        }
    }

   
    void Start ()
    {
        CreateFlag = false;
	}
	
    public void Create()
    {
        if (CreateFlag) return;

        CreateFlag = true;

        var obj = (GameObject)Instantiate(window, transform.position, transform.rotation);
        var mwin = obj.GetComponent<iWindow>();
        mwin.SetManager(this);

        obj.transform.SetParent(transform, false);
        obj.transform.localPosition -= transform.localPosition;

    }
}

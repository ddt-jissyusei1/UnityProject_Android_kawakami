﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public interface iWindow
{
    void SetManager(iCreateFrag _manager);
}

public class Window : MonoBehaviour,iWindow
{
    [SerializeField]
    GameObject[] UIs;//Window内のUIをセット
    [SerializeField]
    Button Close;


    iCreateFrag manager;
    public void SetManager(iCreateFrag _manager)
    {
        manager = _manager;
    }

	void Start ()
    {
        Close.onClick.AddListener(() => Destroy());//イベント登録
	}
	
	void Destroy()
    {
        manager.IsCrete = false;
        Destroy(gameObject);
    }
    


}
